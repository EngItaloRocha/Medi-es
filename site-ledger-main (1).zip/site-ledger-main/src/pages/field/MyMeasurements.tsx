import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatBRL, formatDate } from "@/lib/format";

export default function MyMeasurements() {
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("field_measurements")
        .select("*, projects(name)")
        .eq("foreman_id", user!.id)
        .order("created_at", { ascending: false });
      setItems(data || []);
    })();
  }, [user]);

  const statusColor = (s: string) =>
    s === "approved" ? "bg-success text-success-foreground" :
    s === "rejected" ? "bg-destructive text-destructive-foreground" : "bg-warning text-warning-foreground";
  const statusLabel = (s: string) =>
    s === "approved" ? "Aprovada" : s === "rejected" ? "Rejeitada" : "Pendente";

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Minhas Medições</h1>
        <p className="text-sm text-muted-foreground">Histórico de envios</p>
      </div>
      {items.length === 0 && <Card><CardContent className="py-10 text-center text-muted-foreground">Você ainda não enviou medições.</CardContent></Card>}
      {items.map(m => (
        <Card key={m.id} className="shadow-card">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="min-w-0">
                <p className="font-semibold truncate">{m.projects?.name}</p>
                <p className="text-xs text-muted-foreground">{formatDate(m.period_start)} – {formatDate(m.period_end)}</p>
              </div>
              <Badge className={statusColor(m.status)}>{statusLabel(m.status)}</Badge>
            </div>
            <div className="grid grid-cols-3 gap-2 text-sm mt-3">
              <div><p className="text-xs text-muted-foreground">Mão de Obra</p><p className="font-medium">{formatBRL(m.total_labor)}</p></div>
              <div><p className="text-xs text-muted-foreground">Materiais</p><p className="font-medium">{formatBRL(m.total_materials)}</p></div>
              <div><p className="text-xs text-muted-foreground">Total</p><p className="font-bold text-primary">{formatBRL(Number(m.total_labor) + Number(m.total_materials))}</p></div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
