import MeasurementForm from "@/components/MeasurementForm";

export default function FieldForm() {
  return <MeasurementForm />;
}
