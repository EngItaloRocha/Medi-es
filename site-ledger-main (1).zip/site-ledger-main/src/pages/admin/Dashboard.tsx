import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatBRL } from "@/lib/format";
import {
  TrendingUp, TrendingDown, Wallet, Target, Building2, Landmark,
  HardHat, Package, Wrench, Receipt, ShieldCheck, BarChart3,
  ArrowUpRight, ArrowDownRight, Minus,
} from "lucide-react";
import {
  BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip,
  ResponsiveContainer, Legend, CartesianGrid, LineChart, Line, Area, AreaChart,
} from "recharts";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface Tx {
  amount: number;
  type: string;
  occurred_on: string;
  project_id: string | null;
  is_fixed_cost: boolean;
  category: string | null;
}
interface Project { id: string; name: string; }
interface Loan {
  id: string;
  bank: string;
  description: string | null;
  installments_total: number;
  installments_paid: number;
  installment_amount: number;
  next_due_date: string | null;
}

const CHART_COLORS = [
  "hsl(215, 60%, 35%)",
  "hsl(35, 92%, 52%)",
  "hsl(142, 65%, 38%)",
  "hsl(200, 70%, 45%)",
  "hsl(15, 80%, 50%)",
  "hsl(260, 55%, 50%)",
];

function categorizeExpense(cat: string | null): string {
  if (!cat) return "Outros";
  const c = cat.toLowerCase();
  if (c.includes("mão") || c.includes("mao") || c.includes("labor") || c.includes("obra")) return "Mão de Obra";
  if (c.includes("material") || c.includes("insumo")) return "Material";
  if (c.includes("combustível") || c.includes("combustivel") || c.includes("frota")) return "Frota/Combustível";
  if (c.includes("imposto") || c.includes("taxa") || c.includes("tributo") || c.includes("simples")) return "Impostos";
  if (c.includes("admin") || c.includes("escritório") || c.includes("escritorio")) return "Administrativo";
  if (c.includes("equip") || c.includes("ferramenta")) return "Equipamentos";
  if (c.includes("aliment") || c.includes("refeição")) return "Alimentação";
  if (c.includes("frete") || c.includes("transport")) return "Frete/Transporte";
  if (c.includes("serv")) return "Serviços";
  return "Outros";
}

const CATEGORY_COLORS: Record<string, string> = {
  "Mão de Obra": "hsl(215, 60%, 35%)",
  "Material": "hsl(142, 65%, 38%)",
  "Frota/Combustível": "hsl(35, 92%, 52%)",
  "Impostos": "hsl(0, 75%, 50%)",
  "Administrativo": "hsl(200, 65%, 45%)",
  "Equipamentos": "hsl(260, 55%, 50%)",
  "Alimentação": "hsl(15, 80%, 50%)",
  "Frete/Transporte": "hsl(180, 60%, 40%)",
  "Serviços": "hsl(45, 90%, 45%)",
  "Outros": "hsl(215, 20%, 60%)",
};

const CATEGORY_ICONS: Record<string, any> = {
  "Mão de Obra": HardHat,
  "Material": Package,
  "Impostos": Receipt,
  "Administrativo": Wrench,
  "Equipamentos": Wrench,
  "Frota/Combustível": Wrench,
  "Alimentação": Wrench,
  "Frete/Transporte": Wrench,
  "Serviços": Wrench,
  "Outros": Wrench,
};

export default function Dashboard() {
  const [tx, setTx] = useState<Tx[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);
  const [clientPaid, setClientPaid] = useState(0);
  const [laborFromMeasurements, setLaborFromMeasurements] = useState(0);

  useEffect(() => {
    (async () => {
      const [t, p, l, mats, workers] = await Promise.all([
        supabase.from("transactions").select("amount,type,occurred_on,project_id,is_fixed_cost,category"),
        supabase.from("projects").select("id,name"),
        supabase.from("loans").select("*"),
        supabase
          .from("measurement_materials")
          .select("amount, payment_source, measurement:field_measurements!inner(status)" as any),
        supabase
          .from("measurement_workers")
          .select("total, measurement:field_measurements!inner(status)" as any),
      ]);
      setTx((t.data as any) || []);
      setProjects((p.data as any) || []);
      setLoans((l.data as any) || []);

      const cli = ((mats.data as any) || [])
        .filter((m: any) => m.payment_source === "client" && m.measurement?.status === "approved")
        .reduce((s: number, m: any) => s + Number(m.amount), 0);
      setClientPaid(cli);

      const labor = ((workers.data as any) || [])
        .filter((w: any) => w.measurement?.status === "approved")
        .reduce((s: number, w: any) => s + Number(w.total), 0);
      setLaborFromMeasurements(labor);

      setLoading(false);
    })();
  }, []);

  const income = tx.filter(t => t.type === "income").reduce((s, t) => s + Number(t.amount), 0);
  const expense = tx.filter(t => t.type === "expense").reduce((s, t) => s + Number(t.amount), 0);
  const fixedCosts = tx.filter(t => t.type === "expense" && t.is_fixed_cost).reduce((s, t) => s + Number(t.amount), 0);
  const variableCosts = expense - fixedCosts;
  const profit = income - expense;
  const marginRate = income > 0 ? profit / income : 0;
  const breakEven = marginRate < 1 && marginRate > 0 ? fixedCosts / (1 - variableCosts / income) : 0;
  const breakEvenProgress = breakEven > 0 ? Math.min((income / breakEven) * 100, 100) : income > 0 ? 100 : 0;

  // Expense categories breakdown
  const byCat: Record<string, number> = {};
  tx.filter(t => t.type === "expense").forEach(t => {
    const cat = categorizeExpense(t.category);
    byCat[cat] = (byCat[cat] || 0) + Number(t.amount);
  });
  const categoryData = Object.entries(byCat)
    .sort((a, b) => b[1] - a[1])
    .map(([name, value]) => ({ name, value }));

  // Monthly cash flow (last 6 months)
  const byMonth: Record<string, { in: number; out: number }> = {};
  tx.forEach(t => {
    const m = t.occurred_on.slice(0, 7);
    byMonth[m] = byMonth[m] || { in: 0, out: 0 };
    if (t.type === "income") byMonth[m].in += Number(t.amount);
    else byMonth[m].out += Number(t.amount);
  });
  const monthData = Object.entries(byMonth)
    .sort()
    .slice(-8)
    .map(([m, v]) => ({
      month: new Date(m + "-01").toLocaleDateString("pt-BR", { month: "short", year: "2-digit" }),
      Receitas: v.in,
      Despesas: v.out,
      Resultado: v.in - v.out,
    }));

  // Expenses by project
  const byProject: Record<string, number> = {};
  tx.filter(t => t.type === "expense").forEach(t => {
    const key = t.project_id || "sem-obra";
    byProject[key] = (byProject[key] || 0) + Number(t.amount);
  });
  const projectMap = Object.fromEntries(projects.map(p => [p.id, p.name]));
  const projectData = Object.entries(byProject)
    .sort((a, b) => b[1] - a[1])
    .map(([id, v]) => ({ name: projectMap[id] || "Sem obra", value: v }));

  const totalLoansRemaining = loans.reduce((s, l) =>
    s + ((l.installments_total - l.installments_paid) * l.installment_amount), 0);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-64 bg-muted animate-pulse rounded-lg" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-28 bg-muted animate-pulse rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Visao geral financeira · {new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
          </p>
        </div>
        <Badge
          className={cn(
            "text-sm px-3 py-1.5 font-semibold",
            profit >= 0
              ? "bg-success/15 text-success border border-success/30"
              : "bg-destructive/15 text-destructive border border-destructive/30"
          )}
        >
          {profit >= 0 ? <ArrowUpRight className="h-3.5 w-3.5 mr-1" /> : <ArrowDownRight className="h-3.5 w-3.5 mr-1" />}
          {profit >= 0 ? "Lucrando" : "No prejuízo"}
        </Badge>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="Receita Total"
          value={formatBRL(income)}
          icon={TrendingUp}
          color="success"
          trend={income > 0 ? "+receita" : ""}
        />
        <KpiCard
          label="Despesas (Empresa)"
          value={formatBRL(expense)}
          icon={TrendingDown}
          color="destructive"
        />
        <KpiCard
          label="Resultado Líquido"
          value={formatBRL(profit)}
          icon={Wallet}
          color={profit >= 0 ? "primary" : "destructive"}
          highlight
        />
        <KpiCard
          label="Custos c/ Cliente"
          value={formatBRL(clientPaid)}
          icon={Building2}
          color="warning"
          subtitle="Pago pelo cliente"
        />
      </div>

      {/* Secondary metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricTile label="Custos Fixos" value={formatBRL(fixedCosts)} sub="overhead mensal" />
        <MetricTile label="Custos Variáveis" value={formatBRL(variableCosts)} sub="vinculado às obras" />
        <MetricTile label="Margem %" value={`${(marginRate * 100).toFixed(1)}%`} sub="sobre receita" positive={marginRate > 0.15} />
        <MetricTile label="Financi. Restante" value={formatBRL(totalLoansRemaining)} sub="parcelas em aberto" />
      </div>

      {/* Break even */}
      <Card className="shadow-card overflow-hidden">
        <div className="h-1 bg-gradient-to-r from-primary via-accent to-success" />
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="h-4 w-4 text-accent" />
            Análise do Ponto de Equilíbrio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6 items-center">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Receita p/ Equilíbrio</p>
              <p className="text-2xl font-bold">{formatBRL(breakEven)}</p>
              <p className="text-xs text-muted-foreground">
                Margem de contribuição: <span className="font-semibold text-foreground">{(marginRate * 100).toFixed(1)}%</span>
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Receita Atual</p>
              <p className="text-2xl font-bold text-success">{formatBRL(income)}</p>
              <p className="text-xs text-muted-foreground">
                {breakEvenProgress.toFixed(0)}% da meta de equilíbrio
              </p>
            </div>
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-muted-foreground">Progresso</span>
                <span className={cn("font-bold", breakEvenProgress >= 100 ? "text-success" : "text-foreground")}>
                  {breakEvenProgress.toFixed(0)}%
                </span>
              </div>
              <Progress value={breakEvenProgress} className="h-3" />
              <p className={cn("text-xs mt-2", breakEvenProgress >= 100 ? "text-success" : "text-muted-foreground")}>
                {breakEvenProgress >= 100
                  ? "Empresa acima do ponto de equilíbrio"
                  : `Faltam ${formatBRL(Math.max(0, breakEven - income))}`}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cost Breakdown */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              Despesas por Categoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            {categoryData.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">Sem despesas registradas.</p>
            ) : (
              <div className="space-y-3">
                {categoryData.map((cat) => {
                  const pct = expense > 0 ? (cat.value / expense) * 100 : 0;
                  const color = CATEGORY_COLORS[cat.name] || CATEGORY_COLORS["Outros"];
                  const CatIcon = CATEGORY_ICONS[cat.name] || Wrench;
                  return (
                    <div key={cat.name}>
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div
                            className="h-6 w-6 rounded-md flex items-center justify-center"
                            style={{ backgroundColor: color + "22" }}
                          >
                            <CatIcon className="h-3.5 w-3.5" style={{ color }} />
                          </div>
                          <span className="text-sm font-medium">{cat.name}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-xs text-muted-foreground">{pct.toFixed(1)}%</span>
                          <span className="text-sm font-bold">{formatBRL(cat.value)}</span>
                        </div>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{ width: `${pct}%`, backgroundColor: color }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Despesas por Obra</CardTitle>
          </CardHeader>
          <CardContent>
            {projectData.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">Sem dados ainda.</p>
            ) : (
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={projectData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={90}
                    paddingAngle={2}
                  >
                    {projectData.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(v: number) => formatBRL(v)}
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Cash flow chart */}
      <Card className="shadow-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Fluxo de Caixa — Últimos Meses</CardTitle>
        </CardHeader>
        <CardContent>
          {monthData.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-8">Sem dados ainda.</p>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={monthData} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="month"
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={11}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  formatter={(v: number) => formatBRL(v)}
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Receitas" fill="hsl(142, 65%, 38%)" radius={[3, 3, 0, 0]} maxBarSize={32} />
                <Bar dataKey="Despesas" fill="hsl(0, 75%, 50%)" radius={[3, 3, 0, 0]} maxBarSize={32} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Loans */}
      {loans.length > 0 && (
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Landmark className="h-4 w-4 text-primary" />
                Financiamentos
              </CardTitle>
              <Badge variant="outline" className="text-xs">
                Restante: {formatBRL(totalLoansRemaining)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 gap-4">
              {loans.map((l) => {
                const pct = (l.installments_paid / l.installments_total) * 100;
                const remaining = (l.installments_total - l.installments_paid) * l.installment_amount;
                return (
                  <div key={l.id} className="border rounded-xl p-4 hover:border-primary/30 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="font-semibold text-sm">{l.bank}</p>
                        {l.description && (
                          <p className="text-xs text-muted-foreground mt-0.5">{l.description}</p>
                        )}
                      </div>
                      <Badge variant="outline" className="text-xs shrink-0">
                        {l.installments_paid}/{l.installments_total}
                      </Badge>
                    </div>
                    <Progress value={pct} className="h-2 mb-3" />
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-muted-foreground">Parcela mensal</p>
                        <p className="font-semibold">{formatBRL(l.installment_amount)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Saldo devedor</p>
                        <p className="font-semibold text-destructive">{formatBRL(remaining)}</p>
                      </div>
                    </div>
                    {l.next_due_date && (
                      <p className="text-[10px] text-muted-foreground mt-2">
                        Prox. vencimento: {new Date(l.next_due_date).toLocaleDateString("pt-BR")}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function KpiCard({
  label, value, icon: Icon, color, highlight, subtitle, trend,
}: {
  label: string;
  value: string;
  icon: any;
  color: "success" | "destructive" | "primary" | "warning";
  highlight?: boolean;
  subtitle?: string;
  trend?: string;
}) {
  const configs = {
    success: {
      bg: "bg-success/10",
      text: "text-success",
      border: "border-success/20",
      icon: "bg-success/20 text-success",
    },
    destructive: {
      bg: "bg-destructive/10",
      text: "text-destructive",
      border: "border-destructive/20",
      icon: "bg-destructive/20 text-destructive",
    },
    primary: {
      bg: highlight ? "bg-gradient-primary" : "bg-primary/10",
      text: highlight ? "text-primary-foreground" : "text-primary",
      border: highlight ? "border-0" : "border-primary/20",
      icon: highlight ? "bg-white/20 text-primary-foreground" : "bg-primary/20 text-primary",
    },
    warning: {
      bg: "bg-warning/10",
      text: "text-warning-foreground",
      border: "border-warning/20",
      icon: "bg-warning/20 text-warning",
    },
  };
  const cfg = configs[color];

  return (
    <Card className={cn("shadow-card overflow-hidden border", cfg.border, highlight && "border-0")}>
      <CardContent className={cn("p-4 md:p-5", cfg.bg)}>
        <div className="flex items-start justify-between">
          <div className="min-w-0 flex-1">
            <p className={cn("text-xs font-medium uppercase tracking-wider", highlight ? "opacity-75" : "text-muted-foreground")}>
              {label}
            </p>
            <p className={cn("text-xl md:text-2xl font-bold mt-1.5 truncate", cfg.text)}>
              {value}
            </p>
            {subtitle && (
              <p className={cn("text-xs mt-0.5", highlight ? "opacity-60" : "text-muted-foreground")}>
                {subtitle}
              </p>
            )}
          </div>
          <div className={cn("rounded-lg p-2 ml-2 shrink-0", cfg.icon)}>
            <Icon className="h-4 w-4" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function MetricTile({
  label, value, sub, positive,
}: {
  label: string;
  value: string;
  sub?: string;
  positive?: boolean;
}) {
  return (
    <Card className="shadow-card">
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className={cn(
          "text-lg font-bold mt-1",
          positive === true ? "text-success" : positive === false ? "text-destructive" : "text-foreground"
        )}>
          {value}
        </p>
        {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
      </CardContent>
    </Card>
  );
}
