import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus, Upload, Search, Filter, ArrowUpCircle, ArrowDownCircle, Wallet,
  Trash2, Link2, HardHat, Package, Wrench, Building2, Truck, Utensils,
  Receipt, TrendingUp, TrendingDown, BarChart3, ChevronDown, ChevronUp,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatBRL, formatDate } from "@/lib/format";
import ImportWizard from "@/components/ImportWizard";
import PageHeader from "@/components/PageHeader";
import { cn } from "@/lib/utils";

type TxRow = any;

const CATEGORIES = [
  "Mão de Obra", "Material", "Combustível", "Alimentação",
  "Administrativo", "Equipamento", "Frete", "Imposto",
  "Receita medição", "Serviços", "Outro",
];

function categorizeExpense(cat: string | null): string {
  if (!cat) return "Outro";
  const c = cat.toLowerCase();
  if (c.includes("mão") || c.includes("mao") || c.includes("labor") || c.includes("obra")) return "Mão de Obra";
  if (c.includes("material") || c.includes("insumo")) return "Material";
  if (c.includes("combustível") || c.includes("combustivel") || c.includes("combustiv") || c.includes("frota")) return "Combustível";
  if (c.includes("imposto") || c.includes("taxa") || c.includes("tributo") || c.includes("simples")) return "Imposto";
  if (c.includes("admin") || c.includes("escritório") || c.includes("escritorio")) return "Administrativo";
  if (c.includes("equip") || c.includes("ferramenta")) return "Equipamento";
  if (c.includes("aliment") || c.includes("refeição") || c.includes("refeicao")) return "Alimentação";
  if (c.includes("frete") || c.includes("transport")) return "Frete";
  if (c.includes("serv")) return "Serviços";
  return "Outro";
}

const CATEGORY_CONFIG: Record<string, { icon: any; color: string; bg: string; border: string }> = {
  "Mão de Obra":    { icon: HardHat,    color: "text-blue-600",    bg: "bg-blue-50",    border: "border-blue-200" },
  "Material":       { icon: Package,    color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200" },
  "Combustível":    { icon: Truck,      color: "text-orange-600",  bg: "bg-orange-50",  border: "border-orange-200" },
  "Imposto":        { icon: Receipt,    color: "text-red-600",     bg: "bg-red-50",     border: "border-red-200" },
  "Administrativo": { icon: Building2,  color: "text-slate-600",   bg: "bg-slate-50",   border: "border-slate-200" },
  "Equipamento":    { icon: Wrench,     color: "text-amber-600",   bg: "bg-amber-50",   border: "border-amber-200" },
  "Alimentação":    { icon: Utensils,   color: "text-pink-600",    bg: "bg-pink-50",    border: "border-pink-200" },
  "Frete":          { icon: Truck,      color: "text-cyan-600",    bg: "bg-cyan-50",    border: "border-cyan-200" },
  "Serviços":       { icon: Wrench,     color: "text-violet-600",  bg: "bg-violet-50",  border: "border-violet-200" },
  "Outro":          { icon: BarChart3,  color: "text-gray-600",    bg: "bg-gray-50",    border: "border-gray-200" },
};

export default function Transactions() {
  const { toast } = useToast();
  const [tx, setTx] = useState<TxRow[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<"all" | "income" | "expense">("all");
  const [filterProject, setFilterProject] = useState<string>("all");
  const [filterMonth, setFilterMonth] = useState<string>("");
  const [toDelete, setToDelete] = useState<TxRow | null>(null);
  const [showBreakdown, setShowBreakdown] = useState(true);

  const [form, setForm] = useState({
    type: "expense" as "income" | "expense",
    amount: "",
    description: "",
    category: "",
    occurred_on: new Date().toISOString().slice(0, 10),
    project_id: "none",
    is_fixed_cost: false,
  });

  const load = async () => {
    const [t, p] = await Promise.all([
      supabase.from("transactions").select("*, projects(name)").order("occurred_on", { ascending: false }).limit(500),
      supabase.from("projects").select("id,name").order("name"),
    ]);
    setTx((t.data as any) || []);
    setProjects((p.data as any) || []);
  };
  useEffect(() => { load(); }, []);

  const create = async () => {
    const { error } = await supabase.from("transactions").insert({
      type: form.type,
      amount: Number(form.amount),
      description: form.description,
      category: form.category || null,
      occurred_on: form.occurred_on,
      project_id: form.project_id === "none" ? null : form.project_id,
      is_fixed_cost: form.is_fixed_cost,
      source: "manual",
    });
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Lançamento criado" });
    setOpen(false);
    setForm({ ...form, amount: "", description: "", category: "" });
    load();
  };

  const remove = async (row: TxRow) => {
    const { error } = await supabase.from("transactions").delete().eq("id", row.id);
    if (error) { toast({ title: "Erro ao excluir", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Transação excluída" });
    setToDelete(null);
    load();
  };

  const filtered = useMemo(() => {
    return tx.filter((t) => {
      if (filterType !== "all" && t.type !== filterType) return false;
      if (filterProject !== "all" && (t.project_id || "none") !== filterProject) return false;
      if (filterMonth && !String(t.occurred_on).startsWith(filterMonth)) return false;
      if (search && !`${t.description} ${t.category || ""} ${t.projects?.name || ""}`.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [tx, search, filterType, filterProject, filterMonth]);

  const totals = useMemo(() => {
    let income = 0, expense = 0, fixedCost = 0;
    filtered.forEach((t) => {
      if (t.type === "income") income += Number(t.amount);
      else {
        expense += Number(t.amount);
        if (t.is_fixed_cost) fixedCost += Number(t.amount);
      }
    });
    return { income, expense, balance: income - expense, fixedCost, variableCost: expense - fixedCost };
  }, [filtered]);

  const categoryBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    filtered
      .filter((t) => t.type === "expense")
      .forEach((t) => {
        const cat = categorizeExpense(t.category);
        map[cat] = (map[cat] || 0) + Number(t.amount);
      });
    return Object.entries(map)
      .sort((a, b) => b[1] - a[1])
      .map(([name, amount]) => ({ name, amount, pct: totals.expense > 0 ? (amount / totals.expense) * 100 : 0 }));
  }, [filtered, totals.expense]);

  const categoryColor = (cat?: string | null) => {
    if (!cat) return "bg-muted text-muted-foreground border-border";
    const normalized = categorizeExpense(cat);
    const cfg = CATEGORY_CONFIG[normalized];
    if (!cfg) return "bg-muted text-muted-foreground border-border";
    return `${cfg.bg} ${cfg.color} ${cfg.border}`;
  };

  const marginRate = totals.income > 0 ? ((totals.income - totals.expense) / totals.income) * 100 : 0;

  return (
    <div className="space-y-6">
      <PageHeader title="Transações" subtitle={`${filtered.length} lançamentos`} />

      {/* KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-card border-l-4 border-l-success">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Receitas</p>
                <p className="text-2xl font-bold text-success mt-1">{formatBRL(totals.income)}</p>
              </div>
              <div className="rounded-lg bg-success/10 p-2.5">
                <TrendingUp className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card border-l-4 border-l-destructive">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Despesas</p>
                <p className="text-2xl font-bold text-destructive mt-1">{formatBRL(totals.expense)}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  Fixo: {formatBRL(totals.fixedCost)} · Variável: {formatBRL(totals.variableCost)}
                </p>
              </div>
              <div className="rounded-lg bg-destructive/10 p-2.5">
                <TrendingDown className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className={cn("shadow-card border-l-4", totals.balance >= 0 ? "border-l-primary" : "border-l-destructive")}>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Resultado</p>
                <p className={cn("text-2xl font-bold mt-1", totals.balance >= 0 ? "text-primary" : "text-destructive")}>
                  {formatBRL(totals.balance)}
                </p>
              </div>
              <div className={cn("rounded-lg p-2.5", totals.balance >= 0 ? "bg-primary/10" : "bg-destructive/10")}>
                <Wallet className={cn("h-5 w-5", totals.balance >= 0 ? "text-primary" : "text-destructive")} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card border-l-4 border-l-accent">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Margem</p>
                <p className={cn("text-2xl font-bold mt-1", marginRate >= 0 ? "text-success" : "text-destructive")}>
                  {marginRate.toFixed(1)}%
                </p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  {marginRate >= 20 ? "Saudável" : marginRate >= 0 ? "Apertada" : "Negativa"}
                </p>
              </div>
              <div className="rounded-lg bg-accent/10 p-2.5">
                <BarChart3 className="h-5 w-5 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category breakdown */}
      {categoryBreakdown.length > 0 && (
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-primary" />
                Despesas por Categoria
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-xs gap-1"
                onClick={() => setShowBreakdown(!showBreakdown)}
              >
                {showBreakdown ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                {showBreakdown ? "Ocultar" : "Mostrar"}
              </Button>
            </div>
          </CardHeader>
          {showBreakdown && (
            <CardContent className="pt-0">
              <div className="grid sm:grid-cols-2 gap-3">
                {categoryBreakdown.map(({ name, amount, pct }) => {
                  const cfg = CATEGORY_CONFIG[name] || CATEGORY_CONFIG["Outro"];
                  const Icon = cfg.icon;
                  return (
                    <div key={name} className={cn("rounded-lg border p-3 flex items-center gap-3", cfg.bg, cfg.border)}>
                      <div className={cn("rounded-md p-2 bg-white/60", cfg.color)}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className={cn("text-xs font-semibold", cfg.color)}>{name}</span>
                          <span className="text-xs font-bold text-foreground">{formatBRL(amount)}</span>
                        </div>
                        <Progress value={pct} className="h-1.5" />
                        <p className="text-[10px] text-muted-foreground mt-0.5">{pct.toFixed(1)}% do total de despesas</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          )}
        </Card>
      )}

      {/* Filters bar */}
      <Card className="shadow-card">
        <CardContent className="p-3 flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar descrição, categoria ou obra..."
              className="pl-9 h-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={filterType} onValueChange={(v: any) => setFilterType(v)}>
            <SelectTrigger className="h-10 w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="income">Receitas</SelectItem>
              <SelectItem value="expense">Despesas</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterProject} onValueChange={setFilterProject}>
            <SelectTrigger className="h-10 w-[190px]"><SelectValue placeholder="Todos os projetos" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os projetos</SelectItem>
              <SelectItem value="none">Sem obra</SelectItem>
              {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Input
            type="month"
            className="h-10 w-[155px]"
            value={filterMonth}
            onChange={(e) => setFilterMonth(e.target.value)}
          />
          <div className="flex gap-2 ml-auto">
            <Button variant="outline" className="h-10" onClick={() => setImportOpen(true)}>
              <Upload className="h-4 w-4 mr-2" />Importar
            </Button>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="h-10">
                  <Plus className="h-4 w-4 mr-2" />Nova Transação
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Novo Lançamento</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Tipo</Label>
                      <Select value={form.type} onValueChange={(v: any) => setForm({ ...form, type: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="expense">Despesa</SelectItem>
                          <SelectItem value="income">Receita</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div><Label>Valor (R$)</Label><Input type="number" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} /></div>
                  </div>
                  <div><Label>Descrição</Label><Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Categoria</Label>
                      <Select value={form.category || ""} onValueChange={v => setForm({ ...form, category: v })}>
                        <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div><Label>Data</Label><Input type="date" value={form.occurred_on} onChange={e => setForm({ ...form, occurred_on: e.target.value })} /></div>
                  </div>
                  <div>
                    <Label>Obra</Label>
                    <Select value={form.project_id} onValueChange={v => setForm({ ...form, project_id: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Sem obra</SelectItem>
                        {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <Label className="cursor-pointer">Custo fixo</Label>
                      <p className="text-xs text-muted-foreground">Usado no cálculo do ponto de equilíbrio</p>
                    </div>
                    <Switch checked={form.is_fixed_cost} onCheckedChange={v => setForm({ ...form, is_fixed_cost: v })} />
                  </div>
                  <Button className="w-full" onClick={create} disabled={!form.amount || !form.description}>Salvar</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="shadow-card overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="text-xs uppercase tracking-wider text-muted-foreground pl-4">Data</TableHead>
                <TableHead className="text-xs uppercase tracking-wider text-muted-foreground">Descrição</TableHead>
                <TableHead className="text-xs uppercase tracking-wider text-muted-foreground">Projeto</TableHead>
                <TableHead className="text-xs uppercase tracking-wider text-muted-foreground">Categoria</TableHead>
                <TableHead className="text-xs uppercase tracking-wider text-muted-foreground">Origem</TableHead>
                <TableHead className="text-xs uppercase tracking-wider text-muted-foreground text-right pr-4">Valor</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((t) => {
                const isManual = !t.source || t.source === "manual";
                const isMeasurement = t.source === "measurement";
                const normalizedCat = t.category ? categorizeExpense(t.category) : null;
                const catCfg = normalizedCat ? CATEGORY_CONFIG[normalizedCat] : null;
                return (
                  <TableRow key={t.id} className="group hover:bg-muted/30">
                    <TableCell className="text-sm text-muted-foreground whitespace-nowrap pl-4">{formatDate(t.occurred_on)}</TableCell>
                    <TableCell className="font-medium max-w-xs">
                      <div className="flex items-center gap-2">
                        {t.type === "income"
                          ? <ArrowUpCircle className="h-4 w-4 text-success shrink-0" />
                          : <ArrowDownCircle className="h-4 w-4 text-destructive shrink-0" />}
                        <span className="truncate">{t.description}</span>
                        {isMeasurement && (
                          <Badge variant="outline" className="border-primary/30 text-primary text-[10px] gap-1 shrink-0">
                            <Link2 className="h-3 w-3" />Medição
                          </Badge>
                        )}
                        {t.is_fixed_cost && (
                          <Badge variant="outline" className="border-muted text-muted-foreground text-[10px] shrink-0">
                            Fixo
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{t.projects?.name || "—"}</TableCell>
                    <TableCell>
                      {t.category && catCfg ? (
                        <div className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold border", catCfg.bg, catCfg.color, catCfg.border)}>
                          <catCfg.icon className="h-3 w-3" />
                          {normalizedCat}
                        </div>
                      ) : t.category ? (
                        <Badge variant="outline" className="text-[11px]">{t.category}</Badge>
                      ) : null}
                    </TableCell>
                    <TableCell>
                      <span className="text-xs text-muted-foreground capitalize">
                        {t.source === "manual" ? "Manual" : t.source === "measurement" ? "Medição" : t.source === "bank_import" ? "Extrato" : t.source || "—"}
                      </span>
                    </TableCell>
                    <TableCell className={cn("text-right font-semibold whitespace-nowrap pr-4", t.type === "income" ? "text-success" : "text-destructive")}>
                      {t.type === "income" ? "+" : "−"} {formatBRL(t.amount)}
                    </TableCell>
                    <TableCell>
                      {isManual && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition"
                          onClick={() => setToDelete(t)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-16">
                    <Filter className="h-8 w-8 mx-auto mb-3 opacity-20" />
                    <p className="font-medium">Nenhuma transação encontrada</p>
                    <p className="text-sm mt-1 opacity-70">Ajuste os filtros ou adicione um novo lançamento</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <ImportWizard open={importOpen} onOpenChange={setImportOpen} projects={projects} onImported={load} />

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir transação?</AlertDialogTitle>
            <AlertDialogDescription>
              Essa ação não pode ser desfeita. A transação <span className="font-semibold">{toDelete?.description}</span> ({formatBRL(toDelete?.amount)}) será removida permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => toDelete && remove(toDelete)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
