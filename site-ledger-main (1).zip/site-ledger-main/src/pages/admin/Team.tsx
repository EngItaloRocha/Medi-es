import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatBRL } from "@/lib/format";
import PageHeader from "@/components/PageHeader";

interface Worker {
  id: string;
  worker_name: string;
  role: string;
  daily_rate: number;
  active: boolean;
}

const empty = { worker_name: "", role: "PEDREIRO", daily_rate: "", active: true };

export default function Team() {
  const { toast } = useToast();
  const [rates, setRates] = useState<Worker[]>([]);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Worker | null>(null);
  const [form, setForm] = useState<typeof empty>(empty);
  const [confirmDel, setConfirmDel] = useState<Worker | null>(null);

  const load = async () => {
    const { data } = await supabase.from("labor_rates").select("*").order("worker_name");
    setRates((data as Worker[]) || []);
  };
  useEffect(() => { load(); }, []);

  const filtered = rates.filter((r) =>
    [r.worker_name, r.role].join(" ").toLowerCase().includes(search.toLowerCase())
  );

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (r: Worker) => {
    setEditing(r);
    setForm({ worker_name: r.worker_name, role: r.role, daily_rate: String(r.daily_rate), active: r.active });
    setOpen(true);
  };

  const save = async () => {
    const payload = {
      worker_name: form.worker_name,
      role: form.role.toUpperCase(),
      daily_rate: Number(form.daily_rate),
      active: form.active,
    };
    const { error } = editing
      ? await supabase.from("labor_rates").update(payload).eq("id", editing.id)
      : await supabase.from("labor_rates").insert(payload);
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: editing ? "Trabalhador atualizado" : "Trabalhador cadastrado" });
    setOpen(false); setForm(empty); setEditing(null);
    load();
  };

  const remove = async () => {
    if (!confirmDel) return;
    const { error } = await supabase.from("labor_rates").delete().eq("id", confirmDel.id);
    if (error) {
      // Likely FK violation — fallback to deactivation
      const { error: e2 } = await supabase.from("labor_rates").update({ active: false }).eq("id", confirmDel.id);
      if (e2) toast({ title: "Erro", description: e2.message, variant: "destructive" });
      else toast({ title: "Trabalhador desativado", description: "Não foi possível remover (medições vinculadas), foi desativado." });
    } else {
      toast({ title: "Trabalhador removido" });
    }
    setConfirmDel(null);
    load();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Equipe"
        subtitle="Trabalhadores e diárias"
        search={{ value: search, onChange: setSearch, placeholder: "Buscar trabalhador..." }}
        onRefresh={load}
        actions={
          <Button onClick={openNew} className="rounded-full">
            <Plus className="h-4 w-4 mr-1" /> Novo
          </Button>
        }
      />

      <Card className="shadow-card">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Função</TableHead>
                <TableHead className="text-right">Diária</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right w-32">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.worker_name}</TableCell>
                  <TableCell>{r.role}</TableCell>
                  <TableCell className="text-right">{formatBRL(r.daily_rate)}</TableCell>
                  <TableCell>
                    <Badge variant={r.active ? "default" : "secondary"}>
                      {r.active ? "Ativo" : "Inativo"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(r)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setConfirmDel(r)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-10">
                    Nenhum trabalhador cadastrado.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Editar Trabalhador" : "Novo Trabalhador"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Nome *</Label><Input value={form.worker_name} onChange={(e) => setForm({ ...form, worker_name: e.target.value })} /></div>
            <div><Label>Função *</Label><Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value.toUpperCase() })} /></div>
            <div><Label>Diária (R$) *</Label><Input type="number" step="0.01" value={form.daily_rate} onChange={(e) => setForm({ ...form, daily_rate: e.target.value })} /></div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="text-sm font-medium">Ativo</p>
                <p className="text-xs text-muted-foreground">Disponível para seleção em medições</p>
              </div>
              <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={save} disabled={!form.worker_name || !form.daily_rate}>
              {editing ? "Salvar" : "Cadastrar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDel} onOpenChange={(o) => !o && setConfirmDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apagar trabalhador?</AlertDialogTitle>
            <AlertDialogDescription>
              Remover <strong>{confirmDel?.worker_name}</strong>. Se houver medições vinculadas, ele será apenas desativado.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Apagar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
