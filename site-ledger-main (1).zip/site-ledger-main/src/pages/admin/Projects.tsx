import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, Building2, Users, MapPin, Calendar, DollarSign, Building, User as UserIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatBRL } from "@/lib/format";
import PageHeader from "@/components/PageHeader";
import { Progress } from "@/components/ui/progress";

type ProjectStatus = "active" | "paused" | "completed";

interface Project {
  id: string;
  name: string;
  client: string | null;
  address: string | null;
  budget: number | null;
  status: ProjectStatus;
  started_at: string | null;
  ended_at: string | null;
}

const statusLabel: Record<ProjectStatus, { text: string; cls: string }> = {
  active: { text: "Ativo", cls: "bg-success/15 text-success" },
  paused: { text: "Pausado", cls: "bg-warning/15 text-warning" },
  completed: { text: "Concluído", cls: "bg-muted text-muted-foreground" },
};

interface FormState {
  name: string;
  client: string;
  address: string;
  budget: string;
  status: ProjectStatus;
  started_at: string;
  ended_at: string;
  description: string;
}

const emptyForm: FormState = {
  name: "",
  client: "",
  address: "",
  budget: "",
  status: "active",
  started_at: "",
  ended_at: "",
  description: "",
};

export default function Projects() {
  const { toast } = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [tx, setTx] = useState<{ project_id: string | null; amount: number; type: string }[]>([]);
  // Client-paid materials per project (not in transactions table)
  const [clientMatByProj, setClientMatByProj] = useState<Record<string, number>>({});
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [confirmDel, setConfirmDel] = useState<Project | null>(null);

  const load = async () => {
    const [p, t, mats] = await Promise.all([
      supabase.from("projects").select("*").order("created_at", { ascending: false }),
      supabase.from("transactions").select("project_id, amount, type"),
      supabase
        .from("measurement_materials")
        .select("amount, payment_source, measurement:field_measurements!inner(project_id, status)" as any),
    ]);

    setProjects((p.data as Project[]) || []);
    setTx((t.data as any) || []);

    const clientMap: Record<string, number> = {};
    ((mats.data as any) || []).forEach((m: any) => {
      if (m.payment_source !== "client") return;
      if (m.measurement?.status !== "approved") return;
      const pid = m.measurement?.project_id;
      if (!pid) return;
      clientMap[pid] = (clientMap[pid] || 0) + Number(m.amount);
    });
    setClientMatByProj(clientMap);
  };
  useEffect(() => { load(); }, []);

  const totalsBy = useMemo(() => {
    const map: Record<string, { income: number; expense: number }> = {};
    tx.forEach((t) => {
      const k = t.project_id || "_";
      map[k] = map[k] || { income: 0, expense: 0 };
      if (t.type === "income") map[k].income += Number(t.amount);
      else map[k].expense += Number(t.amount);
    });
    return map;
  }, [tx]);

  const filtered = projects.filter((p) =>
    [p.name, p.client, p.address].filter(Boolean).join(" ").toLowerCase().includes(search.toLowerCase()),
  );

  const openNew = () => { setEditing(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (p: Project) => {
    setEditing(p);
    setForm({
      name: p.name,
      client: p.client || "",
      address: p.address || "",
      budget: p.budget ? String(p.budget) : "",
      status: p.status,
      started_at: p.started_at || "",
      ended_at: p.ended_at || "",
      description: "",
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.name) return;
    const payload = {
      name: form.name,
      client: form.client || null,
      address: form.address || null,
      budget: form.budget ? Number(form.budget) : 0,
      status: form.status,
      started_at: form.started_at || null,
      ended_at: form.ended_at || null,
    };
    const { error } = editing
      ? await supabase.from("projects").update(payload).eq("id", editing.id)
      : await supabase.from("projects").insert(payload);
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: editing ? "Obra atualizada" : "Obra cadastrada" });
    setOpen(false); setForm(emptyForm); setEditing(null);
    load();
  };

  const remove = async () => {
    if (!confirmDel) return;
    const { error } = await supabase.from("projects").delete().eq("id", confirmDel.id);
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); }
    else { toast({ title: "Obra removida" }); load(); }
    setConfirmDel(null);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Obras"
        search={{ value: search, onChange: setSearch, placeholder: "Buscar obra..." }}
        onRefresh={load}
        actions={
          <Button onClick={openNew} className="rounded-full">
            <Plus className="h-4 w-4 mr-1" /> Nova Obra
          </Button>
        }
      />

      {filtered.length === 0 ? (
        <Card className="shadow-card">
          <CardContent className="py-16 text-center text-muted-foreground">
            Nenhuma obra encontrada.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p) => {
            const totals = totalsBy[p.id] || { income: 0, expense: 0 };
            const companyCost = totals.expense; // already excludes client-paid materials
            const clientCost = clientMatByProj[p.id] || 0;
            const totalCost = companyCost + clientCost;
            const margin = totals.income > 0 ? ((totals.income - companyCost) / totals.income) * 100 : 0;
            const budgetUsed = p.budget && p.budget > 0 ? Math.min((totalCost / p.budget) * 100, 100) : 0;
            const st = statusLabel[p.status];
            return (
              <Card key={p.id} className="shadow-card hover:shadow-elevated transition-shadow">
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="rounded-lg bg-primary/10 p-2.5">
                      <Building2 className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${st.cls}`}>{st.text}</span>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(p)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setConfirmDel(p)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold text-base leading-tight">{p.name}</h3>
                    {p.client && <p className="text-xs text-muted-foreground mt-1">{p.client}</p>}
                  </div>

                  <div className="space-y-1.5 text-xs text-muted-foreground">
                    {p.address && (
                      <div className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" />{p.address}</div>
                    )}
                    {(p.started_at || p.ended_at) && (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-3.5 w-3.5" />
                        {p.started_at ? new Date(p.started_at).toLocaleDateString("pt-BR") : "—"} → {p.ended_at ? new Date(p.ended_at).toLocaleDateString("pt-BR") : "—"}
                      </div>
                    )}
                  </div>

                  {/* Cost breakdown */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-2 text-center">
                      <div className="flex items-center justify-center gap-1 text-[10px] text-muted-foreground">
                        <Building className="h-3 w-3" /> Empresa
                      </div>
                      <p className="text-xs font-bold text-destructive mt-0.5">{formatBRL(companyCost)}</p>
                    </div>
                    <div className="rounded-lg bg-warning/5 border border-warning/20 p-2 text-center">
                      <div className="flex items-center justify-center gap-1 text-[10px] text-muted-foreground">
                        <UserIcon className="h-3 w-3" /> Cliente
                      </div>
                      <p className="text-xs font-bold text-warning mt-0.5">{formatBRL(clientCost)}</p>
                    </div>
                    <div className="rounded-lg bg-primary/10 p-2 text-center">
                      <div className="text-[10px] text-muted-foreground">Custo Total</div>
                      <p className="text-xs font-bold text-primary mt-0.5">{formatBRL(totalCost)}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="rounded-lg bg-success/10 p-2 text-center">
                      <p className="text-xs font-bold text-success">{formatBRL(totals.income)}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">Receitas</p>
                    </div>
                    <div className={`rounded-lg p-2 text-center ${margin >= 0 ? "bg-success/10" : "bg-destructive/10"}`}>
                      <p className={`text-xs font-bold ${margin >= 0 ? "text-success" : "text-destructive"}`}>
                        {margin.toFixed(1)}%
                      </p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">Margem (caixa)</p>
                    </div>
                  </div>

                  {p.budget ? (
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <DollarSign className="h-3 w-3" />
                          Orçamento: {formatBRL(p.budget)}
                        </span>
                        <span className="font-semibold">{budgetUsed.toFixed(0)}%</span>
                      </div>
                      <Progress value={budgetUsed} className="h-1.5" />
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Form dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? "Editar Obra" : "Nova Obra"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Nome *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Cliente</Label><Input value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} /></div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v: ProjectStatus) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Ativo</SelectItem>
                    <SelectItem value="paused">Pausado</SelectItem>
                    <SelectItem value="completed">Concluído</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Endereço</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Início</Label><Input type="date" value={form.started_at} onChange={(e) => setForm({ ...form, started_at: e.target.value })} /></div>
              <div><Label>Fim previsto</Label><Input type="date" value={form.ended_at} onChange={(e) => setForm({ ...form, ended_at: e.target.value })} /></div>
            </div>
            <div><Label>Orçamento (R$)</Label><Input type="number" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={save} disabled={!form.name}>{editing ? "Salvar" : "Cadastrar"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDel} onOpenChange={(o) => !o && setConfirmDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apagar obra?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação removerá <strong>{confirmDel?.name}</strong>. Transações associadas perderão a referência à obra.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Apagar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
