import PageHeader from "@/components/PageHeader";
import MeasurementForm from "@/components/MeasurementForm";
import { useNavigate } from "react-router-dom";

export default function NewMeasurement() {
  const navigate = useNavigate();
  return (
    <div className="space-y-6">
      <PageHeader title="Nova Medição" subtitle="Registre uma medição manualmente" />
      <MeasurementForm embedded onSubmitted={() => navigate("/aprovacoes")} />
    </div>
  );
}
