import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Check, X, Eye, Loader2, Pencil, Save, Download, Building, User as UserIcon, Trash2, CalendarDays } from "lucide-react";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatBRL, formatDate } from "@/lib/format";
import PageHeader from "@/components/PageHeader";
import { exportMeasurementPDF } from "@/lib/pdf";
import { cn } from "@/lib/utils";

interface Measurement {
  id: string;
  project_id: string;
  foreman_id: string;
  period_start: string;
  period_end: string;
  total_labor: number;
  total_materials: number;
  status: string;
}

type PaymentSource = "company" | "client";

export default function MeasurementsManager() {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [workers, setWorkers] = useState<any[]>([]);
  const [materials, setMaterials] = useState<any[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<"pending" | "approved">("pending");
  const [editMode, setEditMode] = useState(false);
  const [editDates, setEditDates] = useState<{ period_start: string; period_end: string } | null>(null);

  const load = async () => {
    const { data: meas, error } = await supabase
      .from("field_measurements")
      .select("*")
      .in("status", ["pending", "approved"])
      .order("period_end", { ascending: false });

    if (error) {
      toast({ title: "Erro ao carregar medições", description: error.message, variant: "destructive" });
      setItems([]);
      return;
    }

    const list = (meas as Measurement[]) || [];
    if (list.length === 0) { setItems([]); return; }

    const projectIds = [...new Set(list.map((m) => m.project_id))];
    const foremanIds = [...new Set(list.map((m) => m.foreman_id))];

    const [{ data: projects }, { data: profiles }] = await Promise.all([
      supabase.from("projects").select("id,name,address").in("id", projectIds),
      supabase.from("profiles").select("user_id,display_name,full_name").in("user_id", foremanIds),
    ]);

    const projMap = new Map((projects || []).map((p: any) => [p.id, p]));
    const profMap = new Map((profiles || []).map((p: any) => [p.user_id, p.display_name || p.full_name]));

    setItems(
      list.map((m) => ({
        ...m,
        project_name: (projMap.get(m.project_id) as any)?.name || "—",
        project_address: (projMap.get(m.project_id) as any)?.address || "",
        foreman_name: profMap.get(m.foreman_id) || "Encarregado",
      })),
    );
  };
  useEffect(() => { load(); }, []);

  const openDetail = async (m: any, edit = false) => {
    setSelected(m);
    setEditMode(edit || m.status === "pending");
    setEditDates({ period_start: m.period_start, period_end: m.period_end });
    const [w, mt] = await Promise.all([
      supabase.from("measurement_workers").select("*").eq("measurement_id", m.id).order("worker_name"),
      supabase.from("measurement_materials").select("*").eq("measurement_id", m.id).order("supplier"),
    ]);
    setWorkers(w.data || []);
    setMaterials(mt.data || []);
  };

  const saveDates = async () => {
    if (!selected || !editDates) return;
    const { error } = await supabase
      .from("field_measurements")
      .update({ period_start: editDates.period_start, period_end: editDates.period_end })
      .eq("id", selected.id);
    if (error) {
      toast({ title: "Erro ao salvar datas", description: error.message, variant: "destructive" });
      return;
    }
    setSelected((prev: any) => prev ? { ...prev, ...editDates } : prev);
    setItems((prev) => prev.map((it) => it.id === selected.id ? { ...it, ...editDates } : it));
  };

  const updateWorker = async (id: string, days: number, rate: number) => {
    await supabase.from("measurement_workers").update({ days_worked: days, total: days * rate }).eq("id", id);
    if (selected) openDetail(selected, editMode);
  };
  const updateMaterialAmount = async (id: string, amount: number) => {
    await supabase.from("measurement_materials").update({ amount }).eq("id", id);
    if (selected) openDetail(selected, editMode);
  };
  const updateMaterialPaymentSource = async (id: string, payment_source: PaymentSource) => {
    const { error } = await supabase.from("measurement_materials").update({ payment_source } as any).eq("id", id);
    if (error) {
      toast({ title: "Erro", description: error.message, variant: "destructive" });
      return;
    }
    setMaterials((prev) => prev.map((x) => (x.id === id ? { ...x, payment_source } : x)));
  };
  const deleteWorker = async (id: string) => {
    await supabase.from("measurement_workers").delete().eq("id", id);
    if (selected) openDetail(selected, editMode);
  };
  const deleteMaterial = async (id: string) => {
    await supabase.from("measurement_materials").delete().eq("id", id);
    if (selected) openDetail(selected, editMode);
  };

  const recomputeTotals = async (measurement_id: string) => {
    const [w, m] = await Promise.all([
      supabase.from("measurement_workers").select("total").eq("measurement_id", measurement_id),
      supabase.from("measurement_materials").select("amount").eq("measurement_id", measurement_id),
    ]);
    const tl = (w.data || []).reduce((s: number, x: any) => s + Number(x.total), 0);
    const tm = (m.data || []).reduce((s: number, x: any) => s + Number(x.amount), 0);
    await supabase.from("field_measurements").update({ total_labor: tl, total_materials: tm }).eq("id", measurement_id);
  };

  const approve = async (id: string) => {
    setBusy(id);
    await recomputeTotals(id);
    const { error } = await supabase.rpc("approve_measurement", { _measurement_id: id });
    setBusy(null);
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Medição aprovada", description: "Despesas geradas (apenas itens pagos pela empresa)." });
    setSelected(null); load();
  };

  const reapprove = async (id: string) => {
    setBusy(id);
    await saveDates();
    await recomputeTotals(id);
    const { error } = await supabase.rpc("reapprove_measurement", { _measurement_id: id });
    setBusy(null);
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Medição atualizada", description: "Transações regeneradas." });
    setSelected(null); load();
  };

  const reject = async (id: string) => {
    setBusy(id);
    await supabase.from("field_measurements").update({ status: "rejected" }).eq("id", id);
    setBusy(null);
    toast({ title: "Medição rejeitada" });
    setSelected(null); load();
  };

  const handleExport = async (m: any) => {
    try {
      const [w, mt] = await Promise.all([
        supabase.from("measurement_workers").select("*").eq("measurement_id", m.id),
        supabase.from("measurement_materials").select("*").eq("measurement_id", m.id),
      ]);
      exportMeasurementPDF({
        company: "GPS ENGENHARIA E SERVIÇOS LTDA",
        project: m.project_name,
        address: m.project_address,
        period_start: m.period_start,
        period_end: m.period_end,
        workers: w.data || [],
        materials: mt.data || [],
      });
    } catch (e: any) {
      toast({ title: "Erro ao gerar PDF", description: e.message, variant: "destructive" });
    }
  };

  const filtered = items.filter((m) =>
    m.status === tab &&
    [m.project_name, m.foreman_name].join(" ").toLowerCase().includes(search.toLowerCase()),
  );

  const pendingCount = items.filter((m) => m.status === "pending").length;
  const approvedCount = items.filter((m) => m.status === "approved").length;

  const renderTable = (showPdf: boolean) => (
    <Card className="shadow-card">
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Obra</TableHead>
              <TableHead>Encarregado</TableHead>
              <TableHead>Período</TableHead>
              <TableHead className="text-right">Mão Obra</TableHead>
              <TableHead className="text-right">Materiais</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((m) => (
              <TableRow key={m.id}>
                <TableCell className="font-medium">{m.project_name}</TableCell>
                <TableCell>{m.foreman_name}</TableCell>
                <TableCell className="text-sm">{formatDate(m.period_start)} – {formatDate(m.period_end)}</TableCell>
                <TableCell className="text-right">{formatBRL(m.total_labor)}</TableCell>
                <TableCell className="text-right">{formatBRL(m.total_materials)}</TableCell>
                <TableCell className="text-right font-bold">
                  {formatBRL(Number(m.total_labor) + Number(m.total_materials))}
                </TableCell>
                <TableCell>
                  <div className="flex gap-1 justify-end">
                    {m.status === "pending" ? (
                      <Button size="sm" variant="outline" onClick={() => openDetail(m, true)}>
                        <Eye className="h-4 w-4 mr-1" />Revisar
                      </Button>
                    ) : (
                      <>
                        <Button size="sm" variant="ghost" onClick={() => openDetail(m, false)} title="Ver">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => openDetail(m, true)} title="Editar">
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                    {showPdf && (
                      <Button size="sm" variant="outline" onClick={() => handleExport(m)} title="Exportar PDF">
                        <Download className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground py-10">
                  {tab === "pending" ? "Nenhuma medição pendente." : "Nenhuma medição aprovada ainda."}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );

  const detailMatTotals = {
    company: materials.filter((m) => m.payment_source === "company").reduce((s, x) => s + Number(x.amount), 0),
    client: materials.filter((m) => m.payment_source === "client").reduce((s, x) => s + Number(x.amount), 0),
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Medições"
        subtitle={`${pendingCount} pendente(s) · ${approvedCount} aprovada(s)`}
        search={{ value: search, onChange: setSearch, placeholder: "Buscar por obra ou encarregado..." }}
        onRefresh={load}
      />

      <Tabs value={tab} onValueChange={(v: any) => setTab(v)}>
        <TabsList>
          <TabsTrigger value="pending" className="gap-2">
            Pendentes <Badge variant="secondary">{pendingCount}</Badge>
          </TabsTrigger>
          <TabsTrigger value="approved" className="gap-2">
            Histórico <Badge variant="secondary">{approvedCount}</Badge>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="pending" className="mt-4">{renderTable(false)}</TabsContent>
        <TabsContent value="approved" className="mt-4">{renderTable(true)}</TabsContent>
      </Tabs>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 flex-wrap">
                  {selected.status === "approved" ? "Editar Medição Aprovada" : "Revisar Medição"} – {selected.project_name}
                  {selected.status === "approved" && (
                    <Badge className="bg-success text-success-foreground">Aprovada</Badge>
                  )}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                {/* Period dates */}
                <Card className={cn(editMode && "border-primary/30")}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <CalendarDays className="h-4 w-4 text-primary" />
                      <span className="text-sm font-semibold">Período da Medição</span>
                      {!editMode && (
                        <span className="ml-auto text-sm text-muted-foreground">
                          {formatDate(selected.period_start)} — {formatDate(selected.period_end)}
                        </span>
                      )}
                    </div>
                    {editMode && editDates ? (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-xs text-muted-foreground mb-1 block">Data Início</Label>
                          <Input
                            type="date"
                            className="h-10"
                            value={editDates.period_start}
                            onChange={(e) => setEditDates({ ...editDates, period_start: e.target.value })}
                            onBlur={saveDates}
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-muted-foreground mb-1 block">Data Fim</Label>
                          <Input
                            type="date"
                            className="h-10"
                            value={editDates.period_end}
                            onChange={(e) => setEditDates({ ...editDates, period_end: e.target.value })}
                            onBlur={saveDates}
                          />
                        </div>
                      </div>
                    ) : null}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-base">Mão de Obra</CardTitle></CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Trabalhador</TableHead>
                          <TableHead>Função</TableHead>
                          <TableHead className="text-right">Diária</TableHead>
                          <TableHead>Dias</TableHead>
                          <TableHead className="text-right">Total</TableHead>
                          {editMode && <TableHead></TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {workers.map((w) => (
                          <TableRow key={w.id}>
                            <TableCell className="font-medium">{w.worker_name}</TableCell>
                            <TableCell className="text-sm">{w.role}</TableCell>
                            <TableCell className="text-right">{formatBRL(w.daily_rate)}</TableCell>
                            <TableCell>
                              {editMode ? (
                                <Input
                                  type="number"
                                  step="0.5"
                                  className="h-8 w-20"
                                  defaultValue={w.days_worked}
                                  onBlur={(e) => updateWorker(w.id, Number(e.target.value), Number(w.daily_rate))}
                                />
                              ) : (
                                <span>{w.days_worked}</span>
                              )}
                            </TableCell>
                            <TableCell className="text-right font-semibold">{formatBRL(w.total)}</TableCell>
                            {editMode && (
                              <TableCell className="text-right">
                                <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => deleteWorker(w.id)}>
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </TableCell>
                            )}
                          </TableRow>
                        ))}
                        {workers.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={editMode ? 6 : 5} className="text-center text-muted-foreground py-4">
                              Sem trabalhadores
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2 flex-row items-center justify-between space-y-0">
                    <CardTitle className="text-base">Materiais</CardTitle>
                    <div className="text-xs text-muted-foreground space-x-3">
                      <span><Building className="inline h-3 w-3 mr-1" />Empresa: <strong className="text-primary">{formatBRL(detailMatTotals.company)}</strong></span>
                      <span><UserIcon className="inline h-3 w-3 mr-1" />Cliente: <strong className="text-warning">{formatBRL(detailMatTotals.client)}</strong></span>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Pago por</TableHead>
                          <TableHead>Fornecedor</TableHead>
                          <TableHead>Descrição</TableHead>
                          <TableHead className="text-right">Valor</TableHead>
                          {editMode && <TableHead></TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {materials.map((m) => {
                          const ps: PaymentSource = (m.payment_source as PaymentSource) || "company";
                          return (
                            <TableRow key={m.id} className={cn(ps === "client" && "bg-warning/5")}>
                              <TableCell>
                                <button
                                  type="button"
                                  onClick={() =>
                                    editMode && updateMaterialPaymentSource(m.id, ps === "company" ? "client" : "company")
                                  }
                                  disabled={!editMode}
                                  className={cn(
                                    "text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wide whitespace-nowrap",
                                    ps === "company"
                                      ? "bg-primary/15 text-primary"
                                      : "bg-warning/20 text-warning",
                                    editMode && "hover:opacity-80 cursor-pointer",
                                  )}
                                  title={editMode ? "Clique para alternar" : ""}
                                >
                                  {ps === "company" ? "Empresa" : "Cliente"}
                                </button>
                              </TableCell>
                              <TableCell className="font-medium">{m.supplier}</TableCell>
                              <TableCell className="text-sm">{m.description}</TableCell>
                              <TableCell>
                                {editMode ? (
                                  <Input
                                    type="number"
                                    step="0.01"
                                    className="h-8 w-32 text-right"
                                    defaultValue={m.amount}
                                    onBlur={(e) => updateMaterialAmount(m.id, Number(e.target.value))}
                                  />
                                ) : (
                                  <span className="font-semibold block text-right">{formatBRL(m.amount)}</span>
                                )}
                              </TableCell>
                              {editMode && (
                                <TableCell className="text-right">
                                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => deleteMaterial(m.id)}>
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </TableCell>
                              )}
                            </TableRow>
                          );
                        })}
                        {materials.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={editMode ? 5 : 4} className="text-center text-muted-foreground py-4">
                              Sem materiais
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                <div className="flex gap-3 justify-end pt-2 flex-wrap">
                  {selected.status === "approved" && (
                    <Button variant="outline" onClick={() => handleExport(selected)}>
                      <Download className="h-4 w-4 mr-2" />PDF
                    </Button>
                  )}
                  {selected.status === "pending" ? (
                    <>
                      <Button variant="outline" onClick={() => reject(selected.id)} disabled={!!busy}>
                        <X className="h-4 w-4 mr-2" />Rejeitar
                      </Button>
                      <Button
                        onClick={() => approve(selected.id)}
                        disabled={!!busy}
                        className="bg-success hover:bg-success/90 text-success-foreground"
                      >
                        {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Check className="h-4 w-4 mr-2" />}
                        Aprovar e Gerar Despesas
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button variant="outline" onClick={() => setSelected(null)}>Fechar</Button>
                      {editMode && (
                        <Button
                          onClick={() => reapprove(selected.id)}
                          disabled={!!busy}
                          className="bg-primary hover:bg-primary/90"
                        >
                          {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                          Salvar e Regenerar Transações
                        </Button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
