import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatBRL, formatDate } from "@/lib/format";

export default function Loans() {
  const { toast } = useToast();
  const [loans, setLoans] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    bank: "", description: "", principal: "", installment_amount: "",
    installments_total: "", installments_paid: "0", interest_rate: "",
    next_due_date: "", start_date: "",
  });

  const load = async () => {
    const { data } = await supabase.from("loans").select("*").order("created_at", { ascending: false });
    setLoans(data || []);
  };
  useEffect(() => { load(); }, []);

  const create = async () => {
    const { error } = await supabase.from("loans").insert({
      bank: form.bank,
      description: form.description || null,
      principal: Number(form.principal),
      installment_amount: Number(form.installment_amount),
      installments_total: Number(form.installments_total),
      installments_paid: Number(form.installments_paid) || 0,
      interest_rate: form.interest_rate ? Number(form.interest_rate) : null,
      next_due_date: form.next_due_date || null,
      start_date: form.start_date || null,
    });
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: "Financiamento cadastrado" });
    setOpen(false); load();
  };

  const incrementPaid = async (l: any) => {
    if (l.installments_paid >= l.installments_total) return;
    await supabase.from("loans").update({ installments_paid: l.installments_paid + 1 }).eq("id", l.id);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Financiamentos</h1>
          <p className="text-muted-foreground mt-1">Acompanhamento de parcelas</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-2" />Novo</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Novo Financiamento</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Banco</Label><Input value={form.bank} onChange={e => setForm({ ...form, bank: e.target.value })} /></div>
              <div className="col-span-2"><Label>Descrição</Label><Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
              <div><Label>Principal (R$)</Label><Input type="number" value={form.principal} onChange={e => setForm({ ...form, principal: e.target.value })} /></div>
              <div><Label>Valor parcela</Label><Input type="number" value={form.installment_amount} onChange={e => setForm({ ...form, installment_amount: e.target.value })} /></div>
              <div><Label>Nº parcelas</Label><Input type="number" value={form.installments_total} onChange={e => setForm({ ...form, installments_total: e.target.value })} /></div>
              <div><Label>Pagas</Label><Input type="number" value={form.installments_paid} onChange={e => setForm({ ...form, installments_paid: e.target.value })} /></div>
              <div><Label>Taxa (% a.m.)</Label><Input type="number" step="0.01" value={form.interest_rate} onChange={e => setForm({ ...form, interest_rate: e.target.value })} /></div>
              <div><Label>Próx. vencimento</Label><Input type="date" value={form.next_due_date} onChange={e => setForm({ ...form, next_due_date: e.target.value })} /></div>
              <Button className="col-span-2 mt-2" onClick={create} disabled={!form.bank || !form.principal}>Cadastrar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="shadow-card">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Banco</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Progresso</TableHead>
                <TableHead className="text-right">Parcela</TableHead>
                <TableHead>Próx. vencimento</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loans.map(l => {
                const pct = (l.installments_paid / l.installments_total) * 100;
                return (
                  <TableRow key={l.id}>
                    <TableCell className="font-medium">{l.bank}</TableCell>
                    <TableCell>{l.description}</TableCell>
                    <TableCell className="min-w-[180px]">
                      <div className="flex items-center gap-2">
                        <Progress value={pct} className="h-2 flex-1" />
                        <span className="text-xs text-muted-foreground whitespace-nowrap">{l.installments_paid}/{l.installments_total}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{formatBRL(l.installment_amount)}</TableCell>
                    <TableCell>{formatDate(l.next_due_date)}</TableCell>
                    <TableCell><Button size="sm" variant="outline" onClick={() => incrementPaid(l)}>+1 paga</Button></TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
