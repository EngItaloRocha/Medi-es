import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import RequireRole from "@/components/RequireRole";
import AdminLayout from "@/layouts/AdminLayout";
import FieldLayout from "@/layouts/FieldLayout";
import Auth from "./pages/Auth";
import Dashboard from "./pages/admin/Dashboard";
import Projects from "./pages/admin/Projects";
import Transactions from "./pages/admin/Transactions";
import MeasurementsManager from "./pages/admin/MeasurementsManager";
import Team from "./pages/admin/Team";
import Loans from "./pages/admin/Loans";
import NewMeasurement from "./pages/admin/NewMeasurement";
import FieldForm from "./pages/field/FieldForm";
import MyMeasurements from "./pages/field/MyMeasurements";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/auth" element={<Auth />} />

            {/* Admin */}
            <Route element={<RequireRole role="admin"><AdminLayout /></RequireRole>}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/projetos" element={<Projects />} />
              <Route path="/transacoes" element={<Transactions />} />
              <Route path="/medicoes" element={<MeasurementsManager />} />
              <Route path="/medicoes/nova" element={<NewMeasurement />} />
              {/* Legacy redirects */}
              <Route path="/aprovacoes" element={<Navigate to="/medicoes" replace />} />
              <Route path="/historico" element={<Navigate to="/medicoes" replace />} />
              <Route path="/equipe" element={<Team />} />
              <Route path="/financiamentos" element={<Loans />} />
            </Route>

            {/* Foreman */}
            <Route element={<RequireRole role="foreman"><FieldLayout /></RequireRole>}>
              <Route path="/campo" element={<FieldForm />} />
              <Route path="/campo/minhas" element={<MyMeasurements />} />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
