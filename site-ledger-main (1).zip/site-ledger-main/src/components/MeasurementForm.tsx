import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import {
  Plus, Trash2, Send, Loader2, HardHat, Package, Calendar, Building2, FileText, Pencil, Check, X,
} from "lucide-react";
import { formatBRL } from "@/lib/format";
import { cn } from "@/lib/utils";

type PaymentSource = "company" | "client";

interface WorkerLine {
  labor_rate_id: string;
  worker_name: string;
  role: string;
  daily_rate: number;
  days_worked: number;
}
interface MaterialLine {
  supplier: string;
  description: string;
  amount: number;
  payment_source: PaymentSource;
}

interface Props {
  onSubmitted?: () => void;
  embedded?: boolean;
}

export default function MeasurementForm({ onSubmitted, embedded }: Props) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [projects, setProjects] = useState<any[]>([]);
  const [rates, setRates] = useState<any[]>([]);
  const [project_id, setProject] = useState("");
  const today = new Date().toISOString().slice(0, 10);
  const [period_start, setStart] = useState(today);
  const [period_end, setEnd] = useState(today);
  const [notes, setNotes] = useState("");
  const [workers, setWorkers] = useState<WorkerLine[]>([]);
  const [materials, setMaterials] = useState<MaterialLine[]>([]);
  const [pickRate, setPickRate] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Inline edit state
  const [editingWorkerIdx, setEditingWorkerIdx] = useState<number | null>(null);
  const [editingMaterialIdx, setEditingMaterialIdx] = useState<number | null>(null);
  const [matDraft, setMatDraft] = useState<MaterialLine | null>(null);

  useEffect(() => {
    (async () => {
      const [p, r] = await Promise.all([
        supabase.from("projects").select("id,name").eq("status", "active").order("name"),
        supabase.from("labor_rates").select("*").eq("active", true).order("worker_name"),
      ]);
      setProjects(p.data || []);
      setRates(r.data || []);
    })();
  }, []);

  // ----- Workers -----
  const addWorker = () => {
    if (!pickRate) return;
    const r = rates.find((x) => x.id === pickRate);
    if (!r) return;
    if (workers.find((w) => w.labor_rate_id === r.id)) {
      toast({ title: "Trabalhador já adicionado" });
      return;
    }
    setWorkers([
      ...workers,
      { labor_rate_id: r.id, worker_name: r.worker_name, role: r.role, daily_rate: Number(r.daily_rate), days_worked: 1 },
    ]);
    setPickRate("");
  };
  const updWorker = (i: number, days: number) => {
    const next = [...workers];
    next[i].days_worked = Math.max(0, days);
    setWorkers(next);
  };
  const rmWorker = (i: number) => {
    setWorkers(workers.filter((_, j) => j !== i));
    if (editingWorkerIdx === i) setEditingWorkerIdx(null);
  };

  // ----- Materials -----
  const addMaterial = () => {
    const newLine: MaterialLine = { supplier: "", description: "", amount: 0, payment_source: "company" };
    setMaterials([...materials, newLine]);
    setEditingMaterialIdx(materials.length);
    setMatDraft(newLine);
  };
  const startEditMaterial = (i: number) => {
    setEditingMaterialIdx(i);
    setMatDraft({ ...materials[i] });
  };
  const saveMaterial = () => {
    if (editingMaterialIdx === null || !matDraft) return;
    const next = [...materials];
    next[editingMaterialIdx] = { ...matDraft, amount: Number(matDraft.amount) || 0 };
    setMaterials(next);
    setEditingMaterialIdx(null);
    setMatDraft(null);
  };
  const cancelEditMaterial = () => {
    if (editingMaterialIdx !== null && !materials[editingMaterialIdx].supplier && !materials[editingMaterialIdx].description) {
      // Newly added empty row → drop it
      setMaterials(materials.filter((_, j) => j !== editingMaterialIdx));
    }
    setEditingMaterialIdx(null);
    setMatDraft(null);
  };
  const rmMaterial = (i: number) => {
    setMaterials(materials.filter((_, j) => j !== i));
    if (editingMaterialIdx === i) {
      setEditingMaterialIdx(null);
      setMatDraft(null);
    }
  };

  const totalLabor = workers.reduce((s, w) => s + w.daily_rate * w.days_worked, 0);
  const totalMatCompany = materials
    .filter((m) => m.payment_source === "company")
    .reduce((s, m) => s + Number(m.amount || 0), 0);
  const totalMatClient = materials
    .filter((m) => m.payment_source === "client")
    .reduce((s, m) => s + Number(m.amount || 0), 0);
  const totalMaterials = totalMatCompany + totalMatClient;
  const total = totalLabor + totalMaterials;

  const submit = async () => {
    if (!project_id) {
      toast({ title: "Selecione uma obra", variant: "destructive" });
      return;
    }
    if (workers.length === 0 && materials.length === 0) {
      toast({ title: "Adicione ao menos um trabalhador ou material", variant: "destructive" });
      return;
    }
    if (editingMaterialIdx !== null) {
      toast({ title: "Conclua a edição do material em aberto", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    const { data: meas, error } = await supabase
      .from("field_measurements")
      .insert({
        project_id,
        foreman_id: user!.id,
        period_start,
        period_end,
        notes,
        total_labor: totalLabor,
        total_materials: totalMaterials,
      })
      .select()
      .single();
    if (error || !meas) {
      setSubmitting(false);
      toast({ title: "Erro", description: error?.message, variant: "destructive" });
      return;
    }

    if (workers.length) {
      await supabase.from("measurement_workers").insert(
        workers.map((w) => ({
          measurement_id: meas.id,
          labor_rate_id: w.labor_rate_id,
          worker_name: w.worker_name,
          role: w.role,
          daily_rate: w.daily_rate,
          days_worked: w.days_worked,
          total: w.daily_rate * w.days_worked,
        })),
      );
    }
    if (materials.length) {
      await supabase.from("measurement_materials").insert(
        materials.map((m) => ({
          measurement_id: meas.id,
          supplier: m.supplier,
          description: m.description,
          amount: Number(m.amount),
          payment_source: m.payment_source,
          occurred_on: period_end,
        })),
      );
    }
    setSubmitting(false);
    toast({ title: "Medição enviada!", description: "Aguardando aprovação do administrador." });
    setProject("");
    setWorkers([]);
    setMaterials([]);
    setNotes("");
    onSubmitted?.();
  };

  const stepNum = (n: number) => (
    <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
      {n}
    </span>
  );

  return (
    <div className="space-y-5 max-w-3xl mx-auto">
      {!embedded && (
        <div>
          <h1 className="text-2xl font-bold">Nova Medição</h1>
          <p className="text-sm text-muted-foreground">Registre a mão de obra e materiais do período</p>
        </div>
      )}

      {/* Step 1 — Obra & Período */}
      <Card className="shadow-card border-l-4 border-l-primary">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center gap-3">
            {stepNum(1)}
            <h2 className="font-semibold flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" /> Obra & Período
            </h2>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Obra *</Label>
            <Select value={project_id} onValueChange={setProject}>
              <SelectTrigger className="h-12 text-base mt-1">
                <SelectValue placeholder="Selecione a obra" />
              </SelectTrigger>
              <SelectContent>
                {projects.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> Início</Label>
              <Input type="date" className="h-12 mt-1" value={period_start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="h-3 w-3" /> Fim</Label>
              <Input type="date" className="h-12 mt-1" value={period_end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step 2 — Mão de obra */}
      <Card className="shadow-card border-l-4 border-l-accent">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {stepNum(2)}
              <h2 className="font-semibold flex items-center gap-2">
                <HardHat className="h-4 w-4 text-accent" /> Mão de Obra
              </h2>
            </div>
            {workers.length > 0 && (
              <span className="text-sm font-bold text-primary">{formatBRL(totalLabor)}</span>
            )}
          </div>
          <div className="flex gap-2">
            <Select value={pickRate} onValueChange={setPickRate}>
              <SelectTrigger className="h-12 text-base flex-1">
                <SelectValue placeholder="Selecione trabalhador" />
              </SelectTrigger>
              <SelectContent>
                {rates
                  .filter((r) => !workers.find((w) => w.labor_rate_id === r.id))
                  .map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.worker_name} · {r.role} · {formatBRL(r.daily_rate)}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Button size="lg" onClick={addWorker} disabled={!pickRate} className="h-12 px-4">
              <Plus className="h-5 w-5" />
            </Button>
          </div>
          <div className="space-y-2">
            {workers.map((w, i) => (
              <div key={i} className="rounded-lg border bg-muted/40 p-3">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold truncate">{w.worker_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {w.role} · {formatBRL(w.daily_rate)}/dia
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setEditingWorkerIdx(editingWorkerIdx === i ? null : i)}
                      className="h-8 w-8 -mt-1"
                      title="Editar"
                    >
                      <Pencil className={cn("h-4 w-4", editingWorkerIdx === i && "text-primary")} />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => rmWorker(i)} className="h-8 w-8 -mt-1 -mr-1" title="Remover">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      className="h-9 w-9"
                      onClick={() => updWorker(i, w.days_worked - 0.5)}
                    >
                      −
                    </Button>
                    <Input
                      type="number"
                      step="0.5"
                      min="0"
                      className="h-9 w-16 text-center font-semibold"
                      value={w.days_worked}
                      onChange={(e) => updWorker(i, Number(e.target.value))}
                    />
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      className="h-9 w-9"
                      onClick={() => updWorker(i, w.days_worked + 0.5)}
                    >
                      +
                    </Button>
                    <span className="text-xs text-muted-foreground">dias</span>
                  </div>
                  <span className="ml-auto font-bold text-primary">{formatBRL(w.daily_rate * w.days_worked)}</span>
                </div>
              </div>
            ))}
            {workers.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-3 italic">Nenhum trabalhador adicionado</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Step 3 — Materiais */}
      <Card className="shadow-card border-l-4 border-l-success">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {stepNum(3)}
              <h2 className="font-semibold flex items-center gap-2">
                <Package className="h-4 w-4 text-success" /> Materiais
              </h2>
            </div>
            {materials.length > 0 && (
              <div className="text-right text-xs">
                <p className="font-bold text-primary">{formatBRL(totalMaterials)}</p>
                <p className="text-muted-foreground">
                  Empresa {formatBRL(totalMatCompany)} · Cliente {formatBRL(totalMatClient)}
                </p>
              </div>
            )}
          </div>

          {materials.map((m, i) => {
            const isEditing = editingMaterialIdx === i;
            const draft = isEditing ? matDraft! : m;
            return (
              <div
                key={i}
                className={cn(
                  "rounded-lg border p-3 space-y-2",
                  m.payment_source === "client" ? "bg-warning/5 border-warning/30" : "bg-muted/40",
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-muted-foreground">Item {i + 1}</span>
                    <span
                      className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide",
                        m.payment_source === "company"
                          ? "bg-primary/15 text-primary"
                          : "bg-warning/20 text-warning-foreground",
                      )}
                    >
                      {m.payment_source === "company" ? "Empresa" : "Cliente"}
                    </span>
                  </div>
                  <div className="flex gap-1">
                    {!isEditing && (
                      <Button size="icon" variant="ghost" onClick={() => startEditMaterial(i)} className="h-7 w-7" title="Editar">
                        <Pencil className="h-4 w-4" />
                      </Button>
                    )}
                    <Button size="icon" variant="ghost" onClick={() => rmMaterial(i)} className="h-7 w-7" title="Remover">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>

                {isEditing ? (
                  <>
                    <Input
                      placeholder="Fornecedor"
                      className="h-11"
                      value={draft.supplier}
                      onChange={(e) => setMatDraft({ ...draft, supplier: e.target.value })}
                    />
                    <Input
                      placeholder="Descrição do material"
                      className="h-11"
                      value={draft.description}
                      onChange={(e) => setMatDraft({ ...draft, description: e.target.value })}
                    />
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground font-medium">R$</span>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0,00"
                        className="h-11 pl-10 text-base font-semibold"
                        value={draft.amount || ""}
                        onChange={(e) => setMatDraft({ ...draft, amount: Number(e.target.value) })}
                      />
                    </div>
                    <div className="rounded-md border bg-card p-2.5">
                      <Label className="text-xs font-semibold text-muted-foreground block mb-2">Quem pagou?</Label>
                      <RadioGroup
                        value={draft.payment_source}
                        onValueChange={(v: PaymentSource) => setMatDraft({ ...draft, payment_source: v })}
                        className="grid grid-cols-2 gap-2"
                      >
                        <label
                          className={cn(
                            "flex items-center gap-2 rounded-md border p-2.5 cursor-pointer text-sm transition-colors",
                            draft.payment_source === "company"
                              ? "border-primary bg-primary/10 font-semibold"
                              : "hover:bg-muted",
                          )}
                        >
                          <RadioGroupItem value="company" />
                          Empresa
                        </label>
                        <label
                          className={cn(
                            "flex items-center gap-2 rounded-md border p-2.5 cursor-pointer text-sm transition-colors",
                            draft.payment_source === "client"
                              ? "border-warning bg-warning/15 font-semibold"
                              : "hover:bg-muted",
                          )}
                        >
                          <RadioGroupItem value="client" />
                          Cliente
                        </label>
                      </RadioGroup>
                    </div>
                    <div className="flex gap-2 justify-end pt-1">
                      <Button size="sm" variant="ghost" onClick={cancelEditMaterial}>
                        <X className="h-4 w-4 mr-1" /> Cancelar
                      </Button>
                      <Button size="sm" onClick={saveMaterial}>
                        <Check className="h-4 w-4 mr-1" /> Confirmar
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold truncate">{m.supplier || <span className="italic text-muted-foreground">Sem fornecedor</span>}</p>
                      <p className="text-xs text-muted-foreground truncate">{m.description || "—"}</p>
                    </div>
                    <span className="font-bold text-primary whitespace-nowrap">{formatBRL(m.amount)}</span>
                  </div>
                )}
              </div>
            );
          })}

          <Button variant="outline" className="w-full h-12 border-dashed" onClick={addMaterial} disabled={editingMaterialIdx !== null}>
            <Plus className="h-4 w-4 mr-2" />Adicionar material
          </Button>
        </CardContent>
      </Card>

      {/* Step 4 — Observações */}
      <Card className="shadow-card border-l-4 border-l-muted">
        <CardContent className="p-5 space-y-3">
          <div className="flex items-center gap-3">
            {stepNum(4)}
            <h2 className="font-semibold flex items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" /> Observações (opcional)
            </h2>
          </div>
          <Textarea rows={3} placeholder="Adicione observações sobre o período..." value={notes} onChange={(e) => setNotes(e.target.value)} />
        </CardContent>
      </Card>

      {/* Sticky total */}
      <div className="sticky bottom-4 rounded-xl bg-gradient-primary text-primary-foreground p-4 shadow-elevated z-10">
        <div className="flex justify-between items-center mb-3">
          <div>
            <p className="text-xs opacity-80">TOTAL GERAL</p>
            <p className="text-3xl font-bold">{formatBRL(total)}</p>
          </div>
          <div className="text-right text-xs opacity-80 space-y-0.5">
            <p>Mão de obra: {formatBRL(totalLabor)}</p>
            <p>Materiais Empresa: {formatBRL(totalMatCompany)}</p>
            <p>Materiais Cliente: {formatBRL(totalMatClient)}</p>
          </div>
        </div>
        <Button
          size="lg"
          className="w-full h-14 text-base bg-accent text-accent-foreground hover:bg-accent/90 font-bold"
          onClick={submit}
          disabled={submitting}
        >
          {submitting ? <Loader2 className="h-5 w-5 mr-2 animate-spin" /> : <Send className="h-5 w-5 mr-2" />}
          Enviar para Aprovação
        </Button>
      </div>
    </div>
  );
}
