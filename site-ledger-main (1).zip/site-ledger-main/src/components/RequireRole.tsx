import { Navigate } from "react-router-dom";
import { useAuth, AppRole } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";

export default function RequireRole({ role, children }: { role?: AppRole; children: React.ReactNode }) {
  const { user, role: userRole, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gradient-subtle">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  if (!user) return <Navigate to="/auth" replace />;
  if (role && userRole !== role) {
    return <Navigate to={userRole === "admin" ? "/" : "/campo"} replace />;
  }
  return <>{children}</>;
}
