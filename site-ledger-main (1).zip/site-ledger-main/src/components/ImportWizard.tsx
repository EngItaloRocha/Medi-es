import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Sparkles, FileText, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL, formatDate } from "@/lib/format";

interface ParsedTx {
  date: string;
  description: string;
  amount: number;
  category?: string;
  type?: "income" | "expense";
  project_id?: string | "none";
  selected?: boolean;
}

const COMMON_CATEGORIES = ["Material", "Mão de obra", "Combustível", "Alimentação", "Administrativo", "Equipamento", "Frete", "Imposto", "Receita medição", "Outro"];

export default function ImportWizard({ open, onOpenChange, projects, onImported }: { open: boolean; onOpenChange: (o: boolean) => void; projects: any[]; onImported: () => void }) {
  const { toast } = useToast();
  const [step, setStep] = useState<"upload" | "review">("upload");
  const [parsing, setParsing] = useState(false);
  const [items, setItems] = useState<ParsedTx[]>([]);

  const reset = () => { setStep("upload"); setItems([]); };

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setParsing(true);
    try {
      const ext = file.name.toLowerCase().split(".").pop();
      let parsed: ParsedTx[] = [];
      if (ext === "ofx" || ext === "qfx") parsed = await parseOFX(await file.text());
      else if (ext === "csv") parsed = await parseCSV(await file.text());
      else if (ext === "pdf") parsed = await parsePDFviaAI(file);
      else throw new Error("Formato não suportado. Use OFX, CSV ou PDF.");
      if (parsed.length === 0) throw new Error("Nenhuma transação encontrada no arquivo.");
      setItems(parsed.map(p => ({ ...p, selected: true, project_id: "none", type: p.type || (p.amount < 0 ? "expense" : "income"), amount: Math.abs(p.amount) })));
      setStep("review");
    } catch (err: any) {
      toast({ title: "Erro ao processar", description: err.message, variant: "destructive" });
    } finally {
      setParsing(false);
      e.target.value = "";
    }
  };

  const importAll = async () => {
    const sel = items.filter(i => i.selected && i.amount > 0 && i.description);
    if (sel.length === 0) { toast({ title: "Nada para importar" }); return; }
    const rows = sel.map(s => ({
      type: s.type!,
      amount: s.amount,
      description: s.description,
      category: s.category || null,
      occurred_on: s.date,
      project_id: s.project_id === "none" ? null : s.project_id,
      source: "bank_import",
    }));
    const { error } = await supabase.from("transactions").insert(rows);
    if (error) { toast({ title: "Erro", description: error.message, variant: "destructive" }); return; }
    toast({ title: `${rows.length} lançamentos importados` });
    onImported(); onOpenChange(false); reset();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) reset(); }}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-accent" />
            Importação Inteligente de Extratos
          </DialogTitle>
        </DialogHeader>

        {step === "upload" && (
          <div className="space-y-4 py-4">
            <Card>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  <FormatBox icon={FileText} title="OFX/QFX" desc="Extratos bancários (Bradesco, Itaú, etc.)" />
                  <FormatBox icon={FileText} title="CSV" desc="Planilhas exportadas do banco" />
                  <FormatBox icon={Sparkles} title="PDF (com IA)" desc="Faturas de cartão de crédito" />
                </div>
                <Label className="block mb-2">Selecione o arquivo</Label>
                <div className="flex items-center gap-2">
                  <Input type="file" accept=".ofx,.qfx,.csv,.pdf" onChange={handleFile} disabled={parsing} className="cursor-pointer" />
                  {parsing && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
                </div>
                {parsing && <p className="text-sm text-muted-foreground mt-3">Processando... PDFs com IA podem levar até 30s.</p>}
              </CardContent>
            </Card>
          </div>
        )}

        {step === "review" && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-sm text-muted-foreground">{items.filter(i => i.selected).length} de {items.length} selecionados</p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep("upload")}>Voltar</Button>
                <Button onClick={importAll}>Importar {items.filter(i => i.selected).length} lançamentos</Button>
              </div>
            </div>
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-10"><input type="checkbox" checked={items.every(i => i.selected)} onChange={e => setItems(items.map(i => ({ ...i, selected: e.target.checked })))} /></TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Obra</TableHead>
                      <TableHead className="text-right">Valor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((it, i) => (
                      <TableRow key={i}>
                        <TableCell><input type="checkbox" checked={it.selected} onChange={e => updateItem(i, { selected: e.target.checked })} /></TableCell>
                        <TableCell className="text-sm">{formatDate(it.date)}</TableCell>
                        <TableCell><Input className="h-8" value={it.description} onChange={e => updateItem(i, { description: e.target.value })} /></TableCell>
                        <TableCell>
                          <Select value={it.type} onValueChange={v => updateItem(i, { type: v as any })}>
                            <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="expense">Despesa</SelectItem>
                              <SelectItem value="income">Receita</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Select value={it.category || ""} onValueChange={v => updateItem(i, { category: v })}>
                            <SelectTrigger className="h-8 w-36"><SelectValue placeholder="—" /></SelectTrigger>
                            <SelectContent>
                              {COMMON_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Select value={it.project_id} onValueChange={v => updateItem(i, { project_id: v as any })}>
                            <SelectTrigger className="h-8 w-40"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">Sem obra</SelectItem>
                              {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="text-right font-medium">{formatBRL(it.amount)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );

  function updateItem(i: number, patch: Partial<ParsedTx>) {
    setItems(prev => prev.map((it, j) => j === i ? { ...it, ...patch } : it));
  }
}

function FormatBox({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="rounded-lg border p-4 text-center">
      <Icon className="h-8 w-8 mx-auto text-primary mb-2" />
      <p className="font-semibold text-sm">{title}</p>
      <p className="text-xs text-muted-foreground mt-1">{desc}</p>
    </div>
  );
}

// ---------- OFX Parser ----------
async function parseOFX(text: string): Promise<ParsedTx[]> {
  const txs: ParsedTx[] = [];
  const blocks = text.match(/<STMTTRN>[\s\S]*?<\/STMTTRN>/g) || [];
  for (const b of blocks) {
    const date = (b.match(/<DTPOSTED>([^<\n]+)/) || [])[1] || "";
    const amount = parseFloat((b.match(/<TRNAMT>([^<\n]+)/) || [])[1] || "0");
    const memo = ((b.match(/<MEMO>([^<\n]+)/) || [])[1] || (b.match(/<NAME>([^<\n]+)/) || [])[1] || "").trim();
    if (!date) continue;
    const iso = `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}`;
    txs.push({ date: iso, description: memo, amount, type: amount < 0 ? "expense" : "income" });
  }
  return txs;
}

// ---------- CSV Parser ----------
async function parseCSV(text: string): Promise<ParsedTx[]> {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return [];
  const sep = lines[0].includes(";") ? ";" : ",";
  const header = lines[0].toLowerCase().split(sep).map(h => h.trim().replace(/^"|"$/g, ""));
  const idxDate = header.findIndex(h => /data|date/.test(h));
  const idxDesc = header.findIndex(h => /hist|desc|memo|lançamento|lancamento/.test(h));
  const idxAmount = header.findIndex(h => /valor|amount|montante/.test(h));
  if (idxDate === -1 || idxAmount === -1) throw new Error("CSV deve conter colunas Data, Descrição e Valor.");
  const txs: ParsedTx[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(sep).map(c => c.trim().replace(/^"|"$/g, ""));
    const rawDate = cols[idxDate];
    const dateIso = rawDate.includes("/") ?
      rawDate.split("/").reverse().join("-") :
      rawDate;
    const rawAmt = cols[idxAmount].replace(/\./g, "").replace(",", ".");
    const amount = parseFloat(rawAmt);
    if (isNaN(amount) || !dateIso) continue;
    txs.push({ date: dateIso, description: cols[idxDesc] || "(sem descrição)", amount });
  }
  return txs;
}

// ---------- PDF via AI ----------
async function parsePDFviaAI(file: File): Promise<ParsedTx[]> {
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  const { data, error } = await supabase.functions.invoke("parse-statement", {
    body: { pdf_base64: base64, filename: file.name },
  });
  if (error) throw new Error(error.message || "Falha ao processar PDF");
  if (!data?.transactions) throw new Error("Resposta inválida da IA");
  return data.transactions;
}
