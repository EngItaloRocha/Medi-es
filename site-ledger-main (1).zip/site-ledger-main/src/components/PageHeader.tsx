import { ReactNode } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Bell, RefreshCw, Search } from "lucide-react";

interface Props {
  title: string;
  subtitle?: string;
  search?: { value: string; onChange: (v: string) => void; placeholder?: string };
  onRefresh?: () => void;
  actions?: ReactNode;
}

export default function PageHeader({ title, subtitle, search, onRefresh, actions }: Props) {
  const { user } = useAuth();
  const today = new Date().toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
  const dateLabel = today.charAt(0).toUpperCase() + today.slice(1);
  const initials = (user?.email || "U").slice(0, 2).toUpperCase();

  return (
    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-2">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">{title}</h1>
        <p className="text-sm text-muted-foreground mt-1 capitalize">
          {subtitle || dateLabel}
        </p>
      </div>
      <div className="flex items-center gap-3">
        {search && (
          <div className="relative flex-1 lg:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={search.placeholder || "Buscar..."}
              value={search.value}
              onChange={(e) => search.onChange(e.target.value)}
              className="pl-9 h-10 rounded-full bg-card"
            />
          </div>
        )}
        {actions}
        <Button variant="ghost" size="icon" className="rounded-full relative">
          <Bell className="h-5 w-5" />
          <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-destructive" />
        </Button>
        {onRefresh && (
          <Button variant="ghost" size="icon" className="rounded-full" onClick={onRefresh}>
            <RefreshCw className="h-5 w-5" />
          </Button>
        )}
        <div className="h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold text-sm shadow-card">
          {initials}
        </div>
      </div>
    </div>
  );
}
