import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

const BRL = (n: any) => "R$ " + Number(n || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fdate = (d: string) => d ? new Date(d).toLocaleDateString("pt-BR") : "-";

interface Args {
  company: string;
  project: string;
  address: string;
  period_start: string;
  period_end: string;
  workers: any[];
  materials: any[];
}

export function exportMeasurementPDF(args: Args) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  let y = 12;

  // Header
  doc.setFillColor(28, 53, 92);
  doc.rect(0, 0, W, 28, "F");
  doc.setTextColor(255);
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.text(args.company, W / 2, 12, { align: "center" });
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("RELATÓRIO DE MEDIÇÃO", W / 2, 19, { align: "center" });
  doc.setFontSize(9);
  doc.text(`Período: ${fdate(args.period_start)} a ${fdate(args.period_end)}`, W / 2, 24, { align: "center" });
  doc.setTextColor(0);
  y = 34;

  // Project info
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text("Obra:", 12, y);
  doc.setFont("helvetica", "normal");
  doc.text(args.project, 28, y);
  y += 5;
  if (args.address) {
    doc.setFont("helvetica", "bold"); doc.text("Endereço:", 12, y);
    doc.setFont("helvetica", "normal"); doc.text(args.address, 32, y);
    y += 6;
  }

  // Materials
  if (args.materials.length) {
    doc.setFillColor(230, 235, 245);
    doc.rect(10, y, W - 20, 7, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(11);
    doc.text("MATERIAL DE CONSTRUÇÃO", 12, y + 5);
    y += 9;

    autoTable(doc, {
      startY: y,
      head: [["Pago por", "Fornecedor", "Data", "Descrição", "Valor"]],
      body: args.materials.map((m: any) => [
        m.payment_source === "client" ? "Cliente" : "Empresa",
        m.supplier,
        fdate(m.occurred_on),
        m.description,
        BRL(m.amount),
      ]),
      theme: "grid",
      headStyles: { fillColor: [28, 53, 92], textColor: 255, fontSize: 9 },
      styles: { fontSize: 9, cellPadding: 2 },
      columnStyles: { 0: { halign: "center", cellWidth: 18 }, 4: { halign: "right" } },
      didParseCell: (data: any) => {
        if (data.section === "body" && data.row.raw[0] === "Cliente") {
          data.cell.styles.textColor = [200, 30, 30];
        }
      },
    });
    y = (doc as any).lastAutoTable.finalY + 3;
    const totMatCompany = args.materials.filter((m: any) => m.payment_source !== "client").reduce((s, m: any) => s + Number(m.amount), 0);
    const totMatClient = args.materials.filter((m: any) => m.payment_source === "client").reduce((s, m: any) => s + Number(m.amount), 0);
    const totMat = totMatCompany + totMatClient;
    doc.setFont("helvetica", "normal"); doc.setFontSize(9);
    doc.text(`Empresa: ${BRL(totMatCompany)}  |  Cliente: ${BRL(totMatClient)}`, 12, y + 5);
    doc.setFont("helvetica", "bold");
    doc.text(`TOTAL MATERIAIS: ${BRL(totMat)}`, W - 12, y + 5, { align: "right" });
    y += 12;
  }

  // Labor
  if (args.workers.length) {
    if (y > 220) { doc.addPage(); y = 15; }
    doc.setFillColor(230, 235, 245);
    doc.rect(10, y, W - 20, 7, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(11);
    doc.text("MÃO DE OBRA", 12, y + 5);
    y += 9;

    autoTable(doc, {
      startY: y,
      head: [["Funcionário", "Função", "Diária", "Dias", "Total"]],
      body: args.workers.map(w => [w.worker_name, w.role, BRL(w.daily_rate), w.days_worked, BRL(w.total)]),
      theme: "grid",
      headStyles: { fillColor: [28, 53, 92], textColor: 255, fontSize: 9 },
      styles: { fontSize: 9, cellPadding: 2 },
      columnStyles: { 2: { halign: "right" }, 3: { halign: "center" }, 4: { halign: "right" } },
    });
    y = (doc as any).lastAutoTable.finalY + 3;
    const totLab = args.workers.reduce((s, w) => s + Number(w.total), 0);
    doc.setFont("helvetica", "bold");
    doc.text(`TOTAL MÃO DE OBRA: ${BRL(totLab)}`, W - 12, y + 5, { align: "right" });
    y += 12;
  }

  // Grand total
  if (y > 250) { doc.addPage(); y = 15; }
  const grand = args.materials.reduce((s, m) => s + Number(m.amount), 0) + args.workers.reduce((s, w) => s + Number(w.total), 0);
  doc.setFillColor(28, 53, 92);
  doc.rect(10, y, W - 20, 12, "F");
  doc.setTextColor(255); doc.setFontSize(13); doc.setFont("helvetica", "bold");
  doc.text("VALOR TOTAL DA MEDIÇÃO", 14, y + 8);
  doc.text(BRL(grand), W - 14, y + 8, { align: "right" });

  // Footer
  doc.setTextColor(120); doc.setFontSize(8); doc.setFont("helvetica", "normal");
  doc.text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, W / 2, 290, { align: "center" });

  doc.save(`Medicao_${args.project.replace(/\s+/g, "_")}_${args.period_end}.pdf`);
}
