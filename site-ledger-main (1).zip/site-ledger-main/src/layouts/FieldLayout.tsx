import { Outlet, useNavigate, NavLink } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { HardHat, LogOut, ClipboardList, ListChecks } from "lucide-react";
import { cn } from "@/lib/utils";

export default function FieldLayout() {
  const { signOut, user } = useAuth();
  const navigate = useNavigate();
  const handleLogout = async () => {
    await signOut();
    navigate("/auth");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-subtle">
      <header className="bg-gradient-primary text-primary-foreground sticky top-0 z-20 shadow-elevated">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-accent p-2">
              <HardHat className="h-5 w-5 text-accent-foreground" />
            </div>
            <div>
              <p className="font-bold leading-none">GPS Engenharia</p>
              <p className="text-xs opacity-80 mt-0.5">Encarregado</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={handleLogout} className="text-primary-foreground hover:bg-white/10">
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>
      <main className="flex-1 p-4 pb-24 max-w-2xl mx-auto w-full">
        <Outlet />
      </main>
      {/* Bottom tab bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t shadow-elevated">
        <div className="grid grid-cols-2 max-w-2xl mx-auto">
          <NavLink to="/campo" end className={({ isActive }) => cn(
            "flex flex-col items-center gap-1 py-3 text-xs font-medium",
            isActive ? "text-primary" : "text-muted-foreground"
          )}>
            <ClipboardList className="h-6 w-6" />
            Nova Medição
          </NavLink>
          <NavLink to="/campo/minhas" className={({ isActive }) => cn(
            "flex flex-col items-center gap-1 py-3 text-xs font-medium",
            isActive ? "text-primary" : "text-muted-foreground"
          )}>
            <ListChecks className="h-6 w-6" />
            Minhas Medições
          </NavLink>
        </div>
      </nav>
    </div>
  );
}
