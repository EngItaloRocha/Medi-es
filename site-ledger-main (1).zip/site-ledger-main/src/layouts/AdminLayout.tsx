import { NavLink, Outlet, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard, FolderKanban, Receipt, Users, ClipboardList,
  Landmark, LogOut, HardHat, Menu, FilePlus, X, ChevronRight,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const adminNav = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard", group: "principal" },
  { to: "/projetos", icon: FolderKanban, label: "Obras", group: "obras" },
  { to: "/medicoes/nova", icon: FilePlus, label: "Nova Medição", group: "obras" },
  { to: "/medicoes", icon: ClipboardList, label: "Medições", group: "obras" },
  { to: "/transacoes", icon: Receipt, label: "Transações", group: "financeiro" },
  { to: "/financiamentos", icon: Landmark, label: "Financiamentos", group: "financeiro" },
  { to: "/equipe", icon: Users, label: "Equipe", group: "equipe" },
];

const groupLabels: Record<string, string> = {
  principal: "Principal",
  obras: "Obras",
  financeiro: "Financeiro",
  equipe: "Equipe",
};

const groups = ["principal", "obras", "financeiro", "equipe"];

export default function AdminLayout() {
  const { signOut, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);

  const handleLogout = async () => {
    await signOut();
    navigate("/auth");
  };

  const initials = (user?.email || "U").slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen flex bg-gradient-subtle">
      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-sidebar text-sidebar-foreground flex flex-col transition-transform duration-300 lg:translate-x-0 shadow-elevated",
        open ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo */}
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-accent p-2 shadow-glow">
                <HardHat className="h-5 w-5 text-accent-foreground" />
              </div>
              <div>
                <p className="font-bold leading-tight text-sm">GPS Engenharia</p>
                <p className="text-[10px] opacity-60 mt-0.5 uppercase tracking-wider">Painel Admin</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 lg:hidden text-sidebar-foreground hover:bg-sidebar-accent"
              onClick={() => setOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {groups.map((group) => {
            const items = adminNav.filter((n) => n.group === group);
            return (
              <div key={group} className="mb-4">
                <p className="text-[10px] uppercase tracking-widest font-semibold opacity-40 px-3 mb-1.5">
                  {groupLabels[group]}
                </p>
                {items.map(({ to, icon: Icon, label }) => {
                  const isActive = to === "/"
                    ? location.pathname === "/"
                    : location.pathname.startsWith(to);
                  return (
                    <NavLink
                      key={to}
                      to={to}
                      end={to === "/"}
                      onClick={() => setOpen(false)}
                      className={cn(
                        "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group relative",
                        isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                          : "text-sidebar-foreground/75 hover:bg-sidebar-accent/40 hover:text-sidebar-foreground"
                      )}
                    >
                      <Icon className={cn("h-4 w-4 shrink-0", isActive ? "text-sidebar-primary" : "opacity-70")} />
                      <span className="flex-1">{label}</span>
                      {isActive && <ChevronRight className="h-3 w-3 opacity-50" />}
                    </NavLink>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-3 px-2 mb-3">
            <div className="h-8 w-8 rounded-full bg-sidebar-accent flex items-center justify-center text-xs font-bold text-sidebar-accent-foreground shrink-0">
              {initials}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium truncate text-sidebar-foreground">{user?.email}</p>
              <p className="text-[10px] opacity-50">Administrador</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground text-xs"
            onClick={handleLogout}
          >
            <LogOut className="h-3.5 w-3.5 mr-2" /> Sair da conta
          </Button>
        </div>
      </aside>

      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/50 backdrop-blur-sm lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-20 bg-card/95 backdrop-blur border-b px-4 py-3 flex items-center gap-3 shadow-sm">
          <Button variant="ghost" size="icon" onClick={() => setOpen(true)} className="h-9 w-9">
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2 flex-1">
            <div className="rounded-lg bg-primary p-1.5">
              <HardHat className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-bold text-sm">GPS Engenharia</span>
          </div>
          <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
            {initials}
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
