export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      field_measurements: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          foreman_id: string
          id: string
          notes: string | null
          period_end: string
          period_start: string
          project_id: string
          status: Database["public"]["Enums"]["measurement_status"]
          total_labor: number | null
          total_materials: number | null
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          foreman_id: string
          id?: string
          notes?: string | null
          period_end: string
          period_start: string
          project_id: string
          status?: Database["public"]["Enums"]["measurement_status"]
          total_labor?: number | null
          total_materials?: number | null
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          foreman_id?: string
          id?: string
          notes?: string | null
          period_end?: string
          period_start?: string
          project_id?: string
          status?: Database["public"]["Enums"]["measurement_status"]
          total_labor?: number | null
          total_materials?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "field_measurements_foreman_profile_fk"
            columns: ["foreman_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "field_measurements_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      labor_rates: {
        Row: {
          active: boolean
          created_at: string
          daily_rate: number
          id: string
          role: string
          updated_at: string
          worker_name: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          daily_rate: number
          id?: string
          role: string
          updated_at?: string
          worker_name: string
        }
        Update: {
          active?: boolean
          created_at?: string
          daily_rate?: number
          id?: string
          role?: string
          updated_at?: string
          worker_name?: string
        }
        Relationships: []
      }
      loans: {
        Row: {
          bank: string
          created_at: string
          description: string | null
          id: string
          installment_amount: number
          installments_paid: number
          installments_total: number
          interest_rate: number | null
          next_due_date: string | null
          principal: number
          start_date: string | null
          updated_at: string
        }
        Insert: {
          bank: string
          created_at?: string
          description?: string | null
          id?: string
          installment_amount: number
          installments_paid?: number
          installments_total: number
          interest_rate?: number | null
          next_due_date?: string | null
          principal: number
          start_date?: string | null
          updated_at?: string
        }
        Update: {
          bank?: string
          created_at?: string
          description?: string | null
          id?: string
          installment_amount?: number
          installments_paid?: number
          installments_total?: number
          interest_rate?: number | null
          next_due_date?: string | null
          principal?: number
          start_date?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      measurement_materials: {
        Row: {
          amount: number
          created_at: string
          description: string
          id: string
          measurement_id: string
          occurred_on: string | null
          payment_source: Database["public"]["Enums"]["payment_source"]
          supplier: string
        }
        Insert: {
          amount: number
          created_at?: string
          description: string
          id?: string
          measurement_id: string
          occurred_on?: string | null
          payment_source?: Database["public"]["Enums"]["payment_source"]
          supplier: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string
          id?: string
          measurement_id?: string
          occurred_on?: string | null
          payment_source?: Database["public"]["Enums"]["payment_source"]
          supplier?: string
        }
        Relationships: [
          {
            foreignKeyName: "measurement_materials_measurement_id_fkey"
            columns: ["measurement_id"]
            isOneToOne: false
            referencedRelation: "field_measurements"
            referencedColumns: ["id"]
          },
        ]
      }
      measurement_workers: {
        Row: {
          created_at: string
          daily_rate: number
          days_worked: number
          id: string
          labor_rate_id: string
          measurement_id: string
          role: string
          total: number
          worker_name: string
        }
        Insert: {
          created_at?: string
          daily_rate: number
          days_worked: number
          id?: string
          labor_rate_id: string
          measurement_id: string
          role: string
          total: number
          worker_name: string
        }
        Update: {
          created_at?: string
          daily_rate?: number
          days_worked?: number
          id?: string
          labor_rate_id?: string
          measurement_id?: string
          role?: string
          total?: number
          worker_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "measurement_workers_labor_rate_id_fkey"
            columns: ["labor_rate_id"]
            isOneToOne: false
            referencedRelation: "labor_rates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "measurement_workers_measurement_id_fkey"
            columns: ["measurement_id"]
            isOneToOne: false
            referencedRelation: "field_measurements"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          full_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      projects: {
        Row: {
          address: string | null
          budget: number | null
          client: string | null
          created_at: string
          ended_at: string | null
          id: string
          name: string
          started_at: string | null
          status: Database["public"]["Enums"]["project_status"]
          updated_at: string
        }
        Insert: {
          address?: string | null
          budget?: number | null
          client?: string | null
          created_at?: string
          ended_at?: string | null
          id?: string
          name: string
          started_at?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          updated_at?: string
        }
        Update: {
          address?: string | null
          budget?: number | null
          client?: string | null
          created_at?: string
          ended_at?: string | null
          id?: string
          name?: string
          started_at?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          updated_at?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          category: string | null
          created_at: string
          created_by: string | null
          description: string
          id: string
          is_fixed_cost: boolean
          measurement_id: string | null
          occurred_on: string
          project_id: string | null
          source: string | null
          type: Database["public"]["Enums"]["transaction_type"]
          updated_at: string
        }
        Insert: {
          amount: number
          category?: string | null
          created_at?: string
          created_by?: string | null
          description: string
          id?: string
          is_fixed_cost?: boolean
          measurement_id?: string | null
          occurred_on: string
          project_id?: string | null
          source?: string | null
          type: Database["public"]["Enums"]["transaction_type"]
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string | null
          created_at?: string
          created_by?: string | null
          description?: string
          id?: string
          is_fixed_cost?: boolean
          measurement_id?: string | null
          occurred_on?: string
          project_id?: string | null
          source?: string | null
          type?: Database["public"]["Enums"]["transaction_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      approve_measurement: {
        Args: { _measurement_id: string }
        Returns: undefined
      }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      reapprove_measurement: {
        Args: { _measurement_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "foreman"
      measurement_status: "pending" | "approved" | "rejected"
      payment_source: "company" | "client"
      project_status: "active" | "paused" | "completed"
      transaction_type: "income" | "expense"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "foreman"],
      measurement_status: ["pending", "approved", "rejected"],
      payment_source: ["company", "client"],
      project_status: ["active", "paused", "completed"],
      transaction_type: ["income", "expense"],
    },
  },
} as const
