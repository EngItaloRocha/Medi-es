-- 1. Add payment_source enum + column
DO $$ BEGIN
  CREATE TYPE public.payment_source AS ENUM ('company', 'client');
EXCEPTION WHEN duplicate_object THEN null; END $$;

ALTER TABLE public.measurement_materials
  ADD COLUMN IF NOT EXISTS payment_source public.payment_source NOT NULL DEFAULT 'company';

-- 2. Replace approve_measurement: skip client-paid items
CREATE OR REPLACE FUNCTION public.approve_measurement(_measurement_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  m RECORD;
  w RECORD;
  mat RECORD;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN
    RAISE EXCEPTION 'Only admins can approve measurements';
  END IF;

  SELECT * INTO m FROM public.field_measurements WHERE id = _measurement_id;
  IF m IS NULL THEN RAISE EXCEPTION 'Measurement not found'; END IF;
  IF m.status = 'approved' THEN RAISE EXCEPTION 'Already approved'; END IF;

  DELETE FROM public.transactions WHERE measurement_id = _measurement_id;

  FOR w IN SELECT * FROM public.measurement_workers WHERE measurement_id = _measurement_id LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', w.total,
            'Mão de obra: ' || w.worker_name || ' (' || w.role || ') - ' || w.days_worked || ' dias',
            'Mão de obra', m.period_end, 'measurement', _measurement_id, auth.uid());
  END LOOP;

  -- Only generate transactions for company-paid materials
  FOR mat IN SELECT * FROM public.measurement_materials
             WHERE measurement_id = _measurement_id AND payment_source = 'company' LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', mat.amount,
            mat.supplier || ' - ' || mat.description,
            'Material', COALESCE(mat.occurred_on, m.period_end), 'measurement', _measurement_id, auth.uid());
  END LOOP;

  UPDATE public.field_measurements
  SET status='approved', approved_by=auth.uid(), approved_at=now()
  WHERE id=_measurement_id;
END;
$$;

-- 3. Replace reapprove_measurement: same skip rule
CREATE OR REPLACE FUNCTION public.reapprove_measurement(_measurement_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  m RECORD;
  w RECORD;
  mat RECORD;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN
    RAISE EXCEPTION 'Only admins can re-approve measurements';
  END IF;

  SELECT * INTO m FROM public.field_measurements WHERE id = _measurement_id;
  IF m IS NULL THEN RAISE EXCEPTION 'Measurement not found'; END IF;

  DELETE FROM public.transactions WHERE measurement_id = _measurement_id;

  FOR w IN SELECT * FROM public.measurement_workers WHERE measurement_id = _measurement_id LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', w.total,
            'Mão de obra: ' || w.worker_name || ' (' || w.role || ') - ' || w.days_worked || ' dias',
            'Mão de obra', m.period_end, 'measurement', _measurement_id, auth.uid());
  END LOOP;

  FOR mat IN SELECT * FROM public.measurement_materials
             WHERE measurement_id = _measurement_id AND payment_source = 'company' LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', mat.amount,
            mat.supplier || ' - ' || mat.description,
            'Material', COALESCE(mat.occurred_on, m.period_end), 'measurement', _measurement_id, auth.uid());
  END LOOP;

  UPDATE public.field_measurements
  SET status='approved', approved_by=auth.uid(), approved_at=now(), updated_at=now()
  WHERE id=_measurement_id;
END;
$$;