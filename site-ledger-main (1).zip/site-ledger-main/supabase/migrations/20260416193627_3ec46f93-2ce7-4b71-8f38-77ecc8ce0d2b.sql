
-- Allow re-approving (editing) approved measurements: regenerate transactions
CREATE OR REPLACE FUNCTION public.reapprove_measurement(_measurement_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  m RECORD;
  w RECORD;
  mat RECORD;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN
    RAISE EXCEPTION 'Only admins can re-approve measurements';
  END IF;

  SELECT * INTO m FROM public.field_measurements WHERE id = _measurement_id;
  IF m IS NULL THEN RAISE EXCEPTION 'Measurement not found'; END IF;

  -- Wipe old generated transactions
  DELETE FROM public.transactions WHERE measurement_id = _measurement_id;

  -- Recreate one tx per worker
  FOR w IN SELECT * FROM public.measurement_workers WHERE measurement_id = _measurement_id LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', w.total,
            'Mão de obra: ' || w.worker_name || ' (' || w.role || ') - ' || w.days_worked || ' dias',
            'Mão de obra', m.period_end, 'measurement', _measurement_id, auth.uid());
  END LOOP;

  -- Recreate one tx per material
  FOR mat IN SELECT * FROM public.measurement_materials WHERE measurement_id = _measurement_id LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', mat.amount,
            mat.supplier || ' - ' || mat.description,
            'Material', COALESCE(mat.occurred_on, m.period_end), 'measurement', _measurement_id, auth.uid());
  END LOOP;

  UPDATE public.field_measurements
  SET status='approved', approved_by=auth.uid(), approved_at=now(), updated_at=now()
  WHERE id=_measurement_id;
END;
$$;
