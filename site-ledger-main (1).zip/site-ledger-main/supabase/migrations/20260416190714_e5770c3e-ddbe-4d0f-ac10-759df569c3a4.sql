
-- Garantir que profiles.user_id é único (necessário para FK)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'profiles_user_id_key'
  ) THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);
  END IF;
END $$;

-- Adicionar FK de field_measurements.foreman_id -> profiles.user_id
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'field_measurements_foreman_profile_fk'
  ) THEN
    ALTER TABLE public.field_measurements
      ADD CONSTRAINT field_measurements_foreman_profile_fk
      FOREIGN KEY (foreman_id) REFERENCES public.profiles(user_id) ON DELETE CASCADE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_field_measurements_foreman ON public.field_measurements(foreman_id);
CREATE INDEX IF NOT EXISTS idx_field_measurements_status ON public.field_measurements(status);
