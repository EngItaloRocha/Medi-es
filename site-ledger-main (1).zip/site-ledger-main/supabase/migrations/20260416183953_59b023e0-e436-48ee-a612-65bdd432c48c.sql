-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('admin', 'foreman');
CREATE TYPE public.transaction_type AS ENUM ('income', 'expense');
CREATE TYPE public.measurement_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE public.project_status AS ENUM ('active', 'paused', 'completed');

-- ============ UPDATED_AT TRIGGER FN ============
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  full_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ USER_ROLES ============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS public.app_role
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT role FROM public.user_roles WHERE user_id = _user_id LIMIT 1
$$;

-- ============ HANDLE NEW USER ============
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  user_count INTEGER;
  assigned_role public.app_role;
BEGIN
  INSERT INTO public.profiles (user_id, display_name, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)),
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );

  SELECT COUNT(*) INTO user_count FROM public.user_roles;
  IF user_count = 0 THEN
    assigned_role := 'admin';
  ELSE
    assigned_role := COALESCE((NEW.raw_user_meta_data->>'role')::public.app_role, 'foreman');
  END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, assigned_role);
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ PROFILES POLICIES ============
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE
  USING (auth.uid() = user_id);
CREATE POLICY "Admins manage profiles" ON public.profiles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ============ USER_ROLES POLICIES ============
CREATE POLICY "Users view own roles" ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage roles" ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ============ PROJECTS ============
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  client TEXT,
  address TEXT,
  status public.project_status NOT NULL DEFAULT 'active',
  budget NUMERIC(14,2) DEFAULT 0,
  started_at DATE,
  ended_at DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_projects_updated BEFORE UPDATE ON public.projects
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE POLICY "Authenticated read projects" ON public.projects FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins manage projects" ON public.projects FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ LABOR_RATES ============
CREATE TABLE public.labor_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_name TEXT NOT NULL,
  role TEXT NOT NULL,
  daily_rate NUMERIC(10,2) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.labor_rates ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_labor_rates_updated BEFORE UPDATE ON public.labor_rates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE POLICY "Authenticated read labor_rates" ON public.labor_rates FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins manage labor_rates" ON public.labor_rates FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ TRANSACTIONS ============
CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  type public.transaction_type NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  description TEXT NOT NULL,
  category TEXT,
  occurred_on DATE NOT NULL,
  source TEXT, -- 'manual','bank_ofx','bank_csv','credit_pdf','measurement'
  measurement_id UUID,
  is_fixed_cost BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_transactions_updated BEFORE UPDATE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX idx_transactions_project ON public.transactions(project_id);
CREATE INDEX idx_transactions_date ON public.transactions(occurred_on);
CREATE POLICY "Admins manage transactions" ON public.transactions FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ FIELD_MEASUREMENTS ============
CREATE TABLE public.field_measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  foreman_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  status public.measurement_status NOT NULL DEFAULT 'pending',
  notes TEXT,
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  total_labor NUMERIC(14,2) DEFAULT 0,
  total_materials NUMERIC(14,2) DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.field_measurements ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_measurements_updated BEFORE UPDATE ON public.field_measurements
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "Foremen view own measurements" ON public.field_measurements FOR SELECT
  USING (foreman_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "Foremen create measurements" ON public.field_measurements FOR INSERT
  WITH CHECK (foreman_id = auth.uid() AND status = 'pending');
CREATE POLICY "Foremen update own pending" ON public.field_measurements FOR UPDATE
  USING (foreman_id = auth.uid() AND status = 'pending');
CREATE POLICY "Admins manage measurements" ON public.field_measurements FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ MEASUREMENT_WORKERS ============
CREATE TABLE public.measurement_workers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  measurement_id UUID NOT NULL REFERENCES public.field_measurements(id) ON DELETE CASCADE,
  labor_rate_id UUID NOT NULL REFERENCES public.labor_rates(id),
  worker_name TEXT NOT NULL,
  role TEXT NOT NULL,
  daily_rate NUMERIC(10,2) NOT NULL,
  days_worked NUMERIC(5,2) NOT NULL,
  total NUMERIC(12,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.measurement_workers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "View workers via measurement" ON public.measurement_workers FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND (m.foreman_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "Foreman insert workers on own pending" ON public.measurement_workers FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND m.foreman_id = auth.uid() AND m.status='pending'));
CREATE POLICY "Foreman update workers on own pending" ON public.measurement_workers FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND m.foreman_id = auth.uid() AND m.status='pending'));
CREATE POLICY "Foreman delete workers on own pending" ON public.measurement_workers FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND m.foreman_id = auth.uid() AND m.status='pending'));
CREATE POLICY "Admins manage workers" ON public.measurement_workers FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ MEASUREMENT_MATERIALS ============
CREATE TABLE public.measurement_materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  measurement_id UUID NOT NULL REFERENCES public.field_measurements(id) ON DELETE CASCADE,
  supplier TEXT NOT NULL,
  description TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  occurred_on DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.measurement_materials ENABLE ROW LEVEL SECURITY;
CREATE POLICY "View materials via measurement" ON public.measurement_materials FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND (m.foreman_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "Foreman insert materials on own pending" ON public.measurement_materials FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND m.foreman_id = auth.uid() AND m.status='pending'));
CREATE POLICY "Foreman update materials on own pending" ON public.measurement_materials FOR UPDATE
  USING (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND m.foreman_id = auth.uid() AND m.status='pending'));
CREATE POLICY "Foreman delete materials on own pending" ON public.measurement_materials FOR DELETE
  USING (EXISTS (SELECT 1 FROM public.field_measurements m WHERE m.id = measurement_id AND m.foreman_id = auth.uid() AND m.status='pending'));
CREATE POLICY "Admins manage materials" ON public.measurement_materials FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ LOANS ============
CREATE TABLE public.loans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bank TEXT NOT NULL,
  description TEXT,
  principal NUMERIC(14,2) NOT NULL,
  installment_amount NUMERIC(12,2) NOT NULL,
  installments_total INTEGER NOT NULL,
  installments_paid INTEGER NOT NULL DEFAULT 0,
  interest_rate NUMERIC(6,3),
  next_due_date DATE,
  start_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.loans ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_loans_updated BEFORE UPDATE ON public.loans
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE POLICY "Admins manage loans" ON public.loans FOR ALL
  USING (public.has_role(auth.uid(),'admin'));

-- ============ APPROVE MEASUREMENT FN ============
-- When admin approves, generate transactions automatically
CREATE OR REPLACE FUNCTION public.approve_measurement(_measurement_id UUID)
RETURNS VOID
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  m RECORD;
  w RECORD;
  mat RECORD;
BEGIN
  IF NOT public.has_role(auth.uid(),'admin') THEN
    RAISE EXCEPTION 'Only admins can approve measurements';
  END IF;

  SELECT * INTO m FROM public.field_measurements WHERE id = _measurement_id;
  IF m IS NULL THEN RAISE EXCEPTION 'Measurement not found'; END IF;
  IF m.status = 'approved' THEN RAISE EXCEPTION 'Already approved'; END IF;

  -- Delete previously generated tx (if re-approving after rejection)
  DELETE FROM public.transactions WHERE measurement_id = _measurement_id;

  -- Insert one tx per worker
  FOR w IN SELECT * FROM public.measurement_workers WHERE measurement_id = _measurement_id LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', w.total,
            'Mão de obra: ' || w.worker_name || ' (' || w.role || ') - ' || w.days_worked || ' dias',
            'Mão de obra', m.period_end, 'measurement', _measurement_id, auth.uid());
  END LOOP;

  -- Insert one tx per material
  FOR mat IN SELECT * FROM public.measurement_materials WHERE measurement_id = _measurement_id LOOP
    INSERT INTO public.transactions (project_id, type, amount, description, category, occurred_on, source, measurement_id, created_by)
    VALUES (m.project_id, 'expense', mat.amount,
            mat.supplier || ' - ' || mat.description,
            'Material', COALESCE(mat.occurred_on, m.period_end), 'measurement', _measurement_id, auth.uid());
  END LOOP;

  UPDATE public.field_measurements
  SET status='approved', approved_by=auth.uid(), approved_at=now()
  WHERE id=_measurement_id;
END;
$$;
