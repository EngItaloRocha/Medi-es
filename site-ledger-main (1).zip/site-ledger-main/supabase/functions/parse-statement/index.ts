import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { pdf_base64, filename } = await req.json();
    if (!pdf_base64) {
      return new Response(JSON.stringify({ error: "pdf_base64 obrigatório" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY não configurada");

    const systemPrompt = `Você é um assistente especializado em extrair transações financeiras de extratos bancários e faturas de cartão de crédito brasileiros (Bradesco, Itaú, Santander, etc.). 
Para cada transação encontrada, extraia: data (formato YYYY-MM-DD, assuma o ano atual se não estiver claro), descrição (o estabelecimento/histórico), e valor (número positivo em reais).
Considere todas as transações como despesas (expense), pois faturas de cartão e débitos representam saídas. Ignore linhas de total, juros, anuidade só se forem agregados, mas inclua taxas individuais.
Retorne SEMPRE via tool call.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "text", text: `Extraia todas as transações desta fatura/extrato (${filename || "arquivo"}). Use ano ${new Date().getFullYear()} se a data não tiver ano explícito.` },
              { type: "image_url", image_url: { url: `data:application/pdf;base64,${pdf_base64}` } },
            ],
          },
        ],
        tools: [{
          type: "function",
          function: {
            name: "save_transactions",
            description: "Salva transações extraídas",
            parameters: {
              type: "object",
              properties: {
                transactions: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      date: { type: "string", description: "YYYY-MM-DD" },
                      description: { type: "string" },
                      amount: { type: "number", description: "valor positivo em reais" },
                      category: { type: "string", description: "categoria sugerida (Combustível, Material, Alimentação, etc.)" },
                    },
                    required: ["date", "description", "amount"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["transactions"],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "save_transactions" } },
      }),
    });

    if (response.status === 429) {
      return new Response(JSON.stringify({ error: "Limite de requisições excedido. Tente em alguns segundos." }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (response.status === 402) {
      return new Response(JSON.stringify({ error: "Créditos da Lovable AI esgotados. Adicione créditos no Workspace." }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (!response.ok) {
      const t = await response.text();
      console.error("AI error", response.status, t);
      throw new Error(`AI gateway erro ${response.status}`);
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("IA não retornou transações estruturadas");
    const args = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify({ transactions: args.transactions || [] }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro desconhecido" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
